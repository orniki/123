interface IRecorderSettings {
    applicationName: string;
    applicationVersion: string;
    eventsLength?: number;
    title?: string;
    throttleTime?: number;
    withReplay?: boolean;
    selfRouter?: boolean;
}
export declare class SessionRecorder {
    private readonly eventsLength;
    private readonly title;
    private readonly throttleTime;
    private readonly withReplay;
    private readonly selfRouter;
    private readonly applicationName;
    private readonly applicationVersion;
    private events;
    private eventsReplay;
    private readonly url;
    private isInitialized;
    constructor(settings: IRecorderSettings);
    initRecorder(): Promise<void>;
    startReplay: () => void;
    private readonly pushClick;
    private readonly pushMousemove;
    private readonly pushOnLeave;
    private setEventListeners;
    private removeEventListeners;
    private sendChunk;
}
export {};
