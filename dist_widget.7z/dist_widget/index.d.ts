import React from 'react';

interface IUbaWidget {
    appName: string;
}
declare const UbaWidget: React.FC<IUbaWidget>;

export { UbaWidget };
