export declare const getConnectedSites: () => Promise<any>;
export declare const getSiteSessions: (site: string | Array<string | null> | null, page: number, perPage?: number, searchText?: string) => Promise<any>;
export declare const getSession: (sessionId: string) => Promise<any>;
