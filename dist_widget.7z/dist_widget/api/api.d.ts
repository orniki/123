export declare const api: import("axios").AxiosInstance;
