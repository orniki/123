export declare const takeScreenshot: (width: string, height: string, url: string) => Promise<any>;
