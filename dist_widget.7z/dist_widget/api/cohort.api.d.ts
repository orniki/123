export declare const getCohorts: (appName: string) => Promise<any>;
interface IPostCohort {
    appName: string;
    name: string;
    color: string;
    background: string;
    filters: {
        search: string;
    };
}
export declare const postCohort: ({ appName, name, color, filters, background, }: IPostCohort) => Promise<import("axios").AxiosResponse<any, any>>;
export declare const deleteCohort: (cohort_id: string) => Promise<import("axios").AxiosResponse<any, any>>;
export {};
