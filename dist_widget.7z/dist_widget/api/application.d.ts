export declare const getApplication: (appName: string, from_date: string) => Promise<any>;
export declare const getApplications: () => Promise<any>;
