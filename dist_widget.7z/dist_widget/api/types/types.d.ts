export interface IBitrixLead {
    bitrix_url: string;
    sessionId: string;
    auth_id: string;
    auth_key: string;
}
export interface IBitrixFormData {
    auth_key?: string;
    auth_id?: string;
    bitrix_url?: string;
}
