import { IBitrixFormData, IBitrixLead } from './types/types';
export declare const postBitrixLead: (data: IBitrixLead) => Promise<import("axios").AxiosResponse<any, any>>;
export declare const getBitrixProfile: (data: IBitrixFormData) => Promise<import("axios").AxiosResponse<any, any>>;
