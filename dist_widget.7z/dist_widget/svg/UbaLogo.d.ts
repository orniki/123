import React from "react";
export declare const UbaLogo: React.FC<React.HTMLAttributes<HTMLDivElement>>;
