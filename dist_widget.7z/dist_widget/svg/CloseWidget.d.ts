import React from "react";
export declare const CloseWidget: React.FC<React.HTMLAttributes<HTMLDivElement>>;
