import React from "react";
export declare const UbaLogoMini: React.FC<React.HTMLAttributes<HTMLDivElement>>;
