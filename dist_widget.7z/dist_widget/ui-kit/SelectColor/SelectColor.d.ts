import React from "react";
interface ISelectColor {
    setPickerColor: (value: {
        color: string;
        background: string;
    }) => void;
}
export declare const SelectColor: React.FC<ISelectColor>;
export {};
