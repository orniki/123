export declare const RadioInputWrapper: import("styled-components").StyledComponent<"div", any, {}, never>;
export declare const RadioLabel: import("styled-components").StyledComponent<"label", any, {}, never>;
export declare const RadioInput: import("styled-components").StyledComponent<"input", any, {
    type: "radio";
}, "type">;
export declare const RadioIcon: import("styled-components").StyledComponent<"span", any, {}, never>;
export declare const CheckedRadioIcon: import("styled-components").StyledComponent<"span", any, {}, never>;
