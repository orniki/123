export declare const StyledTagGroup: import("styled-components").StyledComponent<"div", any, {}, never>;
interface IStyledTag {
    selected: boolean;
    color: string;
    background: string;
}
export declare const StyledTag: import("styled-components").StyledComponent<"div", any, IStyledTag, never>;
export declare const StyledTagAdd: import("styled-components").StyledComponent<"div", any, {}, never>;
export declare const StyledIconTagAdd: import("styled-components").StyledComponent<"img", any, {}, never>;
export declare const StyledCLoseIcon: import("styled-components").StyledComponent<"img", any, {}, never>;
export {};
