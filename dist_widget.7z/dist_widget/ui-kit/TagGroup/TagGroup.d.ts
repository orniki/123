import React from "react";
interface ITagGroupProps {
    tags: Array<ITag>;
    selectable?: {
        selectedTags: Array<string>;
        setSelectedTags: React.Dispatch<React.SetStateAction<Array<string>>>;
    };
    flagCohort: (flag: boolean) => void;
    deleteTag: (value: string) => void;
}
export interface ITag {
    cohort_id: string;
    name: string;
    color: string;
    background: string;
}
export declare const TagGroup: React.FC<ITagGroupProps>;
export {};
