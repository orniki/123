import React from "react";
export declare const AddIcon: React.FC<React.HTMLAttributes<HTMLDivElement>>;
