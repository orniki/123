import React from "react";
export declare const CloseIcon: React.FC<React.HTMLAttributes<HTMLDivElement>>;
