import React from "react";
export interface IInput extends React.InputHTMLAttributes<HTMLInputElement> {
    label?: string;
    fullWidth?: boolean;
    stretch?: boolean;
    borderless?: boolean;
    value?: string;
}
export declare const Input: React.FC<IInput>;
