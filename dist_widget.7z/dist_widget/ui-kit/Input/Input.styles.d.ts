import { IInput } from "./Input";
export declare const InputWrapper: import("styled-components").StyledComponent<"div", any, {}, never>;
export declare const StyledInput: import("styled-components").StyledComponent<"input", any, IInput, never>;
export declare const StyledLabel: import("styled-components").StyledComponent<"label", any, {}, never>;
