import React from "react";
export interface IRadio extends React.InputHTMLAttributes<HTMLInputElement> {
    value: string;
    name?: string;
    label: React.ReactNode;
    onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
}
interface ISegmented {
    name: string;
    radios: Array<IRadio>;
    small?: boolean;
    stretch?: boolean;
    currentValue: string;
    onChange: (value: any) => void;
}
export declare const Segmented: React.FC<ISegmented>;
export {};
