export declare const SegmentedInput: import("styled-components").StyledComponent<"input", any, {}, never>;
export declare const SegmentedLabel: import("styled-components").StyledComponent<"label", any, {
    small?: boolean | undefined;
    stretch?: boolean | undefined;
}, never>;
