export declare const StyledSegmented: import("styled-components").StyledComponent<"div", any, {
    stretch?: boolean | undefined;
}, never>;
