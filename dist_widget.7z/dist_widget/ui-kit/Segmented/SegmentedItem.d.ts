import React, { InputHTMLAttributes } from "react";
export interface IRadio extends InputHTMLAttributes<HTMLInputElement> {
    value: string;
    name?: string;
    label: string | React.ReactNode;
    small?: boolean;
    stretch?: boolean;
    onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
}
export declare const SegmentedItem: React.FC<IRadio>;
