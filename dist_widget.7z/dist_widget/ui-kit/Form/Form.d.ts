import React from "react";
import { FormProps } from "rc-field-form";
export declare const Form: React.FC<FormProps>;
