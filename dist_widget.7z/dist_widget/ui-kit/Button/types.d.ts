import { ButtonHTMLAttributes } from "react";
type TButtonPattern = "text" | "ghost" | "primary" | "danger";
export interface IButton extends ButtonHTMLAttributes<HTMLButtonElement> {
    pattern?: TButtonPattern;
    icon?: React.ReactNode;
    children: React.ReactNode;
}
export {};
