import React from "react";
import { IButton } from "./types";
export declare const Button: React.FC<IButton>;
