import { IButton } from "./types";
export declare const StyledButton: import("styled-components").StyledComponent<"button", any, IButton, never>;
