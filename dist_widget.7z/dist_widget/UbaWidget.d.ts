import React from "react";
interface IUbaWidget {
    appName: string;
}
export declare const UbaWidget: React.FC<IUbaWidget>;
export {};
