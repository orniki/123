export declare const screenshotKey = "/screenshot";
