export declare const baseUrl = "https://uba-tool-api.ru";
