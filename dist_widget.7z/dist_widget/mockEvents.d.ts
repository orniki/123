export declare const mockEvents: {
    selector: {
        yandex: {
            clicks: number;
            color: string;
        };
        google: {
            clicks: number;
            color: string;
        };
    };
    selector2: {
        google: {
            clicks: number;
            color: string;
        };
    };
    selector3: {
        yandex: {
            clicks: number;
            color: string;
        };
    };
    selector4: {
        yandex: {
            clicks: number;
            color: string;
        };
        google: {
            clicks: number;
            color: string;
        };
    };
};
