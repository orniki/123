import React from "react";
interface ITooltips {
    events: Array<object>;
    highestValue: number;
    totalClicks: number;
}
export declare const Tooltips: React.FC<ITooltips>;
export {};
