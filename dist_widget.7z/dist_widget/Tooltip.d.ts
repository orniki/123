import React from "react";
import "./styles.css";
interface ITooltip {
    selector: string;
    value: object;
    highestValue: number;
    totalClicks: number;
}
export declare const Tooltip: React.FC<ITooltip>;
export {};
