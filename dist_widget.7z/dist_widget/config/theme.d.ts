import { DefaultTheme } from "styled-components";
export declare const colorPicker: {
    color: string;
    name: string;
    background: string;
}[];
export declare const lightTheme: DefaultTheme;
