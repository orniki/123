/// <reference types="react" />
export declare const StyledUbaWidget: import("styled-components").StyledComponent<"img", any, {}, never>;
export declare const StyledDrawer: import("styled-components").StyledComponent<"div", any, {
    visible?: boolean | undefined;
}, never>;
export declare const DrawerCloser: import("styled-components").StyledComponent<"img", any, {}, never>;
export declare const DrawerHeader: import("styled-components").StyledComponent<"div", any, {}, never>;
export declare const DrawerLogo: import("styled-components").StyledComponent<"img", any, {}, never>;
export declare const DrawerBody: import("styled-components").StyledComponent<"div", any, {}, never>;
export declare const DrawerButton: import("styled-components").StyledComponent<import("react").FC<import("./ui-kit/Button/types").IButton>, any, {}, never>;
export declare const StyledContainerSelectColor: import("styled-components").StyledComponent<"div", any, {}, never>;
export declare const StyledTooltipWrapper: import("styled-components").StyledComponent<"div", any, {
    top?: string | undefined;
    left?: string | undefined;
}, never>;
export declare const StyledTooltip: import("styled-components").StyledComponent<"div", any, {
    color: string;
}, never>;
