"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// index.ts
var UbaWidget_exports = {};
__export(UbaWidget_exports, {
  UbaWidget: () => UbaWidget
});
module.exports = __toCommonJS(UbaWidget_exports);

// src/UbaWidget.tsx
var import_react5 = require("react");
var import_react_dom = require("react-dom");

// src/config/theme.ts
var colors = {
  mainAccent: "#0071CE",
  hoverAccent: "#005EAC",
  danger: "#EF4058",
  textPrimary: "#3B4168",
  textSecondary: "#6F7C98",
  disabled: "#EAEAF1"
};
var colorPicker = [
  {
    color: "#754AEE",
    name: "majorelle-blue",
    background: "rgba(117,74,238,0.12)"
  },
  {
    color: "#F66854",
    name: "bittersweet",
    background: "rgba(246,104,84,0.12)"
  },
  {
    color: "#FDA078",
    name: "light-salmon",
    background: "rgba(253,160,120,0.12)"
  },
  {
    color: "#E9D100",
    name: "safety-yellow",
    background: "rgba(233,209,0,0.12)"
  },
  {
    color: "#D772CD",
    name: "orchid",
    background: "rgba(215,114,205,0.12)"
  },
  {
    color: "#FF4E4E",
    name: "coral-red",
    background: "rgba(255,78,78,0.12)"
  },
  {
    color: "#0075E9",
    name: "crayola",
    background: "rgba(0,117,233,0.12)"
  },
  {
    color: "#320085",
    name: "persian-indigo",
    background: "rgba(50,0,133,0.12)"
  },
  {
    color: "#61B1FB",
    name: "french-sky-blue",
    background: "rgba(97,177,251,0.12)"
  },
  {
    color: "#72D782",
    name: "pastel-green",
    background: "rgba(114,215,130,0.12)"
  },
  {
    color: "#4CAD5B",
    name: "fern",
    background: "rgba(76,173,91,0.12)"
  },
  {
    color: "#B3E745",
    name: "inchworm",
    background: "rgba(179,231,69,0.12)"
  }
];
var lightTheme = {
  colors,
  borderRadius: 8
};

// src/ui-kit/Button/Button.styles.ts
var import_styled_components = __toESM(require("styled-components"));
var StyledButton = import_styled_components.default.button`
  --accent: ${({ theme }) => theme.colors.mainAccent};
  --hoverAccent: ${({ theme }) => theme.colors.hoverAccent};
  --danger: ${({ theme }) => theme.colors.danger};
  --textSecondary: ${({ theme }) => theme.colors.textSecondary};
  --disabled: ${({ theme }) => theme.colors.disabled};

  font-family: "IBM Plex Sans", Inter, Avenir, system-ui, -apple-system, Roboto,
    sans-serif;
  background-color: transparent;
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;

  cursor: pointer;
  padding: 8px 16px;
  font-weight: 500;
  font-size: 16px;
  line-height: 20px;
  border-radius: 100px;

  ${({ pattern }) => {
  switch (pattern) {
    case "primary":
      return import_styled_components.css`
          background-color: ${({ theme }) => theme.colors.mainAccent || "#0071CE"};
          border: 1px solid transparent;
        `;
    case "ghost":
      return import_styled_components.css`
          border: 1px solid var(--accent);
          color: var(--accent);
          background-color: transparent;
        `;
    case "danger":
      return import_styled_components.css`
          color: var(--textSecondary);
          border: 1px solid transparent;
        `;
    default:
      return import_styled_components.css`
          color: var(--accent);
          background-color: transparent;
          border: 1px solid transparent;
        `;
  }
}}

  &:hover {
    cursor: pointer;

    ${({ pattern }) => {
  switch (pattern) {
    case "primary":
      return import_styled_components.css`
            background: #3a9ae9;
            border: 1px solid transparent;
          `;
    case "ghost":
      return import_styled_components.css`
            background-color: #f5fbff;
            /* border: 1px dashed var(--hoverAccent); */
          `;
    case "danger":
      return import_styled_components.css`
            color: var(--danger);
          `;
    default:
      return import_styled_components.css`
            color: var(--hoverAccent);
            background-color: transparent;
            border: 1px solid transparent;
          `;
  }
}}
  }

  &:active {
    cursor: pointer;

    ${({ pattern }) => {
  switch (pattern) {
    case "primary":
      return import_styled_components.css`
            background: var(--hoverAccent);
          `;
    case "ghost":
      return import_styled_components.css`
            background-color: #f5f5f7;
          `;
    default:
  }
}}
  }

  &:disabled {
    cursor: not-allowed;

    ${({ pattern }) => {
  switch (pattern) {
    case "primary":
      return import_styled_components.css`
            background: var(--disabled);
            background-color: var(--disabled);
            border: 1px solid transparent;
          `;
    case "ghost":
      return import_styled_components.css`
            color: var(--disabled);
            background-color: transparent;
            border: 1px solid var(--disabled);
          `;
    case "danger":
      return import_styled_components.css`
            color: var(--disabled);
          `;
    default:
      return import_styled_components.css`
            color: var(--disabled);
            background-color: transparent;
            border: 1px solid transparent;
          `;
  }
}}
  }
`;
StyledButton.defaultProps = {
  theme: lightTheme
};

// src/ui-kit/Button/Button.tsx
var import_jsx_runtime = require("react/jsx-runtime");
var Button = ({
  pattern,
  icon,
  children,
  ...props
}) => {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(StyledButton, { pattern, ...props, children: [
    icon,
    children
  ] });
};

// src/UbaWidget.styles.ts
var import_styled_components2 = __toESM(require("styled-components"));
var StyledUbaWidget = import_styled_components2.default.img`
  color: inherit;
  border-radius: 50px;
  position: fixed;
  z-index: 9998;
  background-color: white;
  bottom: 20px;
  right: 20px;
  width: 30px;
  height: 30px;
  cursor: pointer;
  object-fit: contain;
  padding: 10px;
  box-shadow: 0 0 8px 0 rgba(34, 5, 140, 0.1);
`;
var StyledDrawer = import_styled_components2.default.div`
  position: fixed;
  height: 100vh;
  width: 414px;
  z-index: 9999;
  right: 0;
  top: 0;
  display: flex;
  gap: 12px;
  flex-direction: column;
  transition: 0.3s;
  background-color: white;
  visibility: ${({ visible }) => visible ? "visible" : "hidden"};
  transform: ${({ visible }) => visible ? "translate(0%)" : "translate(100%)"};
  overflow: scroll;
  box-shadow: -8px 0 12px rgba(0, 0, 0, 0.03);
`;
var DrawerCloser = import_styled_components2.default.img`
  cursor: pointer;
  width: 20px;
  height: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`;
var DrawerHeader = import_styled_components2.default.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 24px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.03);
`;
var DrawerLogo = import_styled_components2.default.img`
  width: 120px;
`;
var DrawerBody = import_styled_components2.default.div`
  display: flex;
  flex-direction: column;
  padding: 24px;
  align-items: flex-start;
  gap: 10px;
`;
var DrawerButton = (0, import_styled_components2.default)(Button)`
  margin-top: auto;
`;
var StyledContainerSelectColor = import_styled_components2.default.div`
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 12px;
  width: fit-content;
`;
var StyledTooltipWrapper = import_styled_components2.default.div`
  display: flex;
  gap: 5px;
  position: absolute;
  z-index: 1000;
  top: ${({ top }) => top};
  left: ${({ left }) => left};

  &:hover > div {
    outline: 1px solid lightgray;
  }
`;
var StyledTooltip = import_styled_components2.default.div`
  cursor: default;
  background-color: ${({ color }) => `${color}44`};
  border-radius: 50px;
  padding: 5px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 20px;
  height: 20px;
  font-size: 10px;
  font-weight: bold;
`;

// src/assets/icons/logoHeader.svg
var logoHeader_default = "./logoHeader-Q74D764Y.svg";

// src/assets/icons/logo.svg
var logo_default = "./logo-ITOH54ID.svg";

// src/assets/icons/close_widget.svg
var close_widget_default = "./close_widget-TNKGN6MW.svg";

// src/ui-kit/Segmented/Segmented.styles.ts
var import_styled_components3 = __toESM(require("styled-components"));
var StyledSegmented = import_styled_components3.default.div`
  display: flex;
  color: black;
  justify-content: ${({ stretch }) => stretch ? "stretch" : "flex-start"};
  width: ${({ stretch }) => stretch ? "100%" : "auto"};
  min-height: 32px;
`;

// src/ui-kit/Segmented/SegmentedItem.tsx
var import_react = require("react");

// src/ui-kit/Segmented/SegmentedItem.styles.ts
var import_styled_components4 = __toESM(require("styled-components"));
var SegmentedInput = import_styled_components4.default.input`
  display: none;
`;
var SegmentedLabel = import_styled_components4.default.label`
  user-select: none;
  display: flex;
  flex: ${({ stretch }) => stretch && "1 1 0px"};
  flex-direction: column;
  align-items: center;
  justify-content: center;
  border-radius: 0;
  border: 1px solid #0071ce;
  padding: ${({ small }) => small ? "4px 8px" : "0.6em 1.2em"};
  font-size: ${({ small }) => small ? "12px" : "1em"};
  font-weight: 500;
  font-family: inherit;
  color: #0071ce;
  background-color: #fafafa;
  cursor: pointer;
  transition: border-color 0.25s;

  input:not(:disabled) + &:hover {
    border-color: #646cff;
  }

  input[type="radio"]:checked + & {
    color: white;
    background: ${({ theme }) => theme?.colors?.mainAccent || "#0071CE"};
  }

  input:disabled + & {
    background-color: #3b3b3b;
    cursor: not-allowed;
  }

  &:first-of-type {
    border-radius: 24px 0 0 24px;
  }

  &:last-of-type {
    border-radius: 0 24px 24px 0;
  }
  &:not(:first-of-type) {
    border-left: none;
  }
`;
SegmentedLabel.defaultProps = {
  theme: lightTheme
};

// src/ui-kit/Segmented/SegmentedItem.tsx
var import_jsx_runtime2 = require("react/jsx-runtime");
var SegmentedItem = ({
  name,
  value,
  label,
  onChange,
  small,
  stretch,
  ...props
}) => {
  const id = (0, import_react.useId)();
  return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_jsx_runtime2.Fragment, { children: [
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
      SegmentedInput,
      {
        type: "radio",
        name: name || "default",
        id,
        value,
        onChange,
        ...props
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
      SegmentedLabel,
      {
        stretch,
        small,
        htmlFor: id,
        className: "ui-radio-label",
        children: label
      }
    )
  ] });
};

// src/ui-kit/Segmented/Segmented.tsx
var import_jsx_runtime3 = require("react/jsx-runtime");
var Segmented = ({
  radios,
  name,
  currentValue,
  onChange,
  small,
  stretch
}) => {
  return /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(StyledSegmented, { stretch, children: radios.map((radio, index) => /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
    SegmentedItem,
    {
      stretch,
      small,
      name,
      value: radio.value,
      label: radio.label,
      checked: currentValue === radio.value,
      onChange: (event) => {
        onChange(event?.target.value);
      }
    },
    index
  )) });
};

// src/ui-kit/Input/Input.tsx
var import_react2 = require("react");

// src/ui-kit/Input/Input.styles.tsx
var import_styled_components5 = __toESM(require("styled-components"));
var InputWrapper = import_styled_components5.default.div`
  color: inherit;
  display: flex;
  flex-direction: column;
  gap: 6px;
`;
var StyledInput = import_styled_components5.default.input`
  color: inherit;
  box-sizing: border-box;
  width: ${({ stretch }) => stretch ? "100%" : "250px"};
  flex-grow: ${({ stretch }) => stretch ? "1" : "0"};
  background-color: transparent;
  outline: none;
  border: ${({ borderless }) => borderless ? "none" : "1px solid #e4e7f2"};
  padding: 10px 16px;
  border-radius: ${({ theme }) => `${theme?.borderRadius || 6}px`};

  &::placeholder {
    color: #909ebb;
  }

  &:focus {
    box-shadow: 0px 4px 8px rgba(0, 113, 206, 0.2);
    outline: ${({ borderless, theme }) => borderless ? "none" : `1px solid ${theme?.colors?.mainAccent || "#0071CE"}`};
  }
`;
var StyledLabel = import_styled_components5.default.label`
  font-weight: 400;
  font-size: 14px;
  line-height: 20px;
  color: #6f7c98;
`;
StyledInput.defaultProps = {
  theme: lightTheme
};

// src/ui-kit/Input/Input.tsx
var import_jsx_runtime4 = require("react/jsx-runtime");
var Input = ({ label, value, ...props }) => {
  const inputId = (0, import_react2.useId)();
  return /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(InputWrapper, { ...props, children: [
    label && /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(StyledLabel, { htmlFor: props.id || inputId, children: label }),
    /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(StyledInput, { value, id: props.id || inputId, ...props })
  ] });
};

// src/Tooltip.tsx
var import_react3 = require("react");
var import_react_tooltip = require("react-tooltip");
var import_jsx_runtime5 = require("react/jsx-runtime");
var Tooltip = ({
  selector,
  value,
  highestValue,
  totalClicks
}) => {
  const id = (0, import_react3.useId)();
  const el = document.querySelector(selector);
  const [coords, setCoords] = (0, import_react3.useState)({ x: 0, y: 0, top: 0, left: 0 });
  const [scrolled, setScrolled] = (0, import_react3.useState)(false);
  const [elTag, setElTag] = (0, import_react3.useState)("");
  const onScroll = () => {
    setScrolled((prev) => !prev);
  };
  (0, import_react3.useEffect)(() => {
    setCoords({
      x: el?.getBoundingClientRect().x || 0,
      y: el?.getBoundingClientRect().y || 0,
      top: (el?.getBoundingClientRect()?.height || 0) / 2 || 0,
      left: (el?.getBoundingClientRect()?.width || 0) / 2 || 0
    });
    setElTag(el?.tagName || "");
  }, [selector, scrolled]);
  (0, import_react3.useEffect)(() => {
    window.addEventListener("scroll", onScroll, { capture: true });
    return () => {
      window.removeEventListener("scroll", onScroll, { capture: true });
    };
  }, []);
  if (!el)
    return null;
  return /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(
    StyledTooltipWrapper,
    {
      onMouseEnter: () => {
        el?.classList.add("outlined-target");
      },
      onMouseLeave: () => {
        el?.classList.remove("outlined-target");
      },
      top: `${coords.y}px`,
      left: `${coords.x + 10}px`,
      "data-tooltip-id": id,
      children: [
        Object.entries(value).map(([k, v], index) => /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(StyledTooltip, { color: v.color, children: v.clicks }, index)),
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
          import_react_tooltip.Tooltip,
          {
            id,
            clickable: true,
            place: "right",
            style: {
              zIndex: 1001,
              backgroundColor: "rgba(18 21 42)",
              opacity: "0.70",
              color: "#E4E7F2"
            },
            children: /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(import_jsx_runtime5.Fragment, { children: [
              "\u042D\u043B\u0435\u043C\u0435\u043D\u0442 - ",
              `<${elTag}/>`,
              " ",
              /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("br", {}),
              "\u041A\u043B\u0438\u043A\u043E\u0432: ",
              /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("br", {}),
              Object.keys(value).map((k, index) => /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(import_jsx_runtime5.Fragment, { children: [
                /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("span", { children: [
                  k === "uba_without_cohorts" ? "" : `${k} - `,
                  value?.[`${k}`].clicks,
                  " (",
                  (100 * value?.[`${k}`].clicks / totalClicks).toFixed(2),
                  "%)"
                ] }, index),
                /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("br", {})
              ] }))
            ] })
          }
        )
      ]
    }
  );
};

// src/Tooltips.tsx
var import_jsx_runtime6 = require("react/jsx-runtime");
var Tooltips = ({
  events,
  highestValue,
  totalClicks
}) => {
  return /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(import_jsx_runtime6.Fragment, { children: Object.entries(events)?.map(([objKey, objValue], index) => /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(
    Tooltip,
    {
      totalClicks,
      selector: objKey,
      value: objValue,
      highestValue
    },
    index
  )) });
};

// src/UbaWidget.tsx
var import_react_router_dom = require("react-router-dom");
var import_swr = __toESM(require("swr"));

// src/constants/baseUrl.ts
var import_meta = {};
var baseUrl = (
  // @ts-ignore
  import_meta.env.VITE_BASE_API || "https://uba-tool-api.ru"
);

// src/api/api.ts
var import_axios = __toESM(require("axios"));
var api = import_axios.default.create({
  baseURL: baseUrl + "/"
});

// src/api/application.ts
var getApplication = (appName, from_date) => {
  return api.get("application/events", {
    params: {
      name: appName,
      from_date
    }
  }).then((response) => {
    return response.data;
  });
};

// src/assets/icons/plusCohort.svg
var plusCohort_default = "./plusCohort-AZAATZRU.svg";

// src/assets/icons/close.svg
var close_default = "./close-WS6LTUVZ.svg";

// src/ui-kit/TagGroup/TagGroup.styles.ts
var import_styled_components6 = __toESM(require("styled-components"));
var StyledTagGroup = import_styled_components6.default.div`
  display: flex;
  font-family: "IBM Plex Sans", sans-serif;
  font-style: normal;
  font-weight: 500;
  font-size: 11px;
  line-height: 14px;
  gap: 6px;
  flex-wrap: wrap;
`;
var StyledTag = import_styled_components6.default.div`
  display: flex;
  user-select: none;
  outline: ${({ selected, color }) => selected ? `1px solid ${color}` : "none"};
  color: ${({ color }) => color};
  background-color: ${({ background }) => background};
  flex-direction: row;
  align-items: center;
  padding: 4px 8px;
  gap: 4px;
  border-radius: 4px;
  width: fit-content;
  height: fit-content;
  cursor: pointer;
  &:hover img {
    display: block;
  }
`;
var StyledTagAdd = import_styled_components6.default.div`
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: flex-end;
  padding: 4px;
  border: 1px dashed #c6c6d0;
  border-radius: 4px;
  color: #c6c6d0;
  cursor: pointer;
`;
var StyledIconTagAdd = import_styled_components6.default.img`
  width: 14px;
  height: 14px;
`;
var StyledCLoseIcon = import_styled_components6.default.img`
  display: none;
  width: 12px;
  height: 12px;
  cursor: pointer;
`;

// src/ui-kit/TagGroup/TagGroup.tsx
var import_jsx_runtime7 = require("react/jsx-runtime");
var TagGroup = ({
  tags,
  selectable,
  flagCohort,
  deleteTag
}) => {
  const handleSelectTag = (el) => {
    if (!selectable)
      return;
    if (selectable.selectedTags.includes(el.cohort_id)) {
      selectable.setSelectedTags(
        selectable.selectedTags.filter((item) => item !== el.cohort_id)
      );
      return;
    }
    selectable.setSelectedTags([...selectable.selectedTags, el.cohort_id]);
  };
  return /* @__PURE__ */ (0, import_jsx_runtime7.jsxs)(StyledTagGroup, { children: [
    tags.map((el, index) => /* @__PURE__ */ (0, import_jsx_runtime7.jsxs)(
      StyledTag,
      {
        color: el.color,
        background: el.background,
        selected: selectable ? selectable.selectedTags.some((item) => item == el.cohort_id) : false,
        onClick: () => {
          handleSelectTag(el);
        },
        children: [
          el.name,
          /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(
            StyledCLoseIcon,
            {
              onClick: () => deleteTag(el.cohort_id),
              src: close_default,
              alt: ""
            }
          )
        ]
      },
      index
    )),
    /* @__PURE__ */ (0, import_jsx_runtime7.jsxs)(
      StyledTagAdd,
      {
        onClick: () => {
          flagCohort(true);
        },
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(StyledIconTagAdd, { src: plusCohort_default, alt: "" }),
          "\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u043A\u043E\u0433\u043E\u0440\u0442\u0443"
        ]
      }
    )
  ] });
};

// src/ui-kit/SelectColor/SelectColor.tsx
var import_react4 = require("react");

// src/ui-kit/SelectColor/SelectColor.styles.ts
var import_styled_components7 = __toESM(require("styled-components"));
var RadioInputWrapper = import_styled_components7.default.div`
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
  padding: 16px;
  gap: 20px;
  background: #ffffff;
  box-shadow: 2px 0.25rem 1rem rgba(33, 33, 42, 0.06);
  border-radius: 0.5rem;
`;
var RadioLabel = import_styled_components7.default.label`
  cursor: pointer;
`;
var RadioInput = import_styled_components7.default.input.attrs({ type: "radio" })`
  position: absolute;
  z-index: -1;
  opacity: 0;
`;
var RadioIcon = import_styled_components7.default.span`
  display: inline-block;
  width: 24px;
  height: 24px;
  flex-shrink: 0;
  flex-grow: 0;
  border: 2px solid #fff;
  border-radius: 50%;
  margin-right: 0.5em;
  background-repeat: no-repeat;
  background-position: center center;
  background-size: 50% 50%;
`;
var CheckedRadioIcon = (0, import_styled_components7.default)(RadioIcon)`
  outline: 2px solid #c6c6d0;
`;

// src/ui-kit/SelectColor/SelectColor.tsx
var import_jsx_runtime8 = require("react/jsx-runtime");
var SelectColor = ({ setPickerColor }) => {
  const [selectedOption, setSelectedOption] = (0, import_react4.useState)("majorelle-blue");
  const handleOptionChange = (el) => {
    setSelectedOption(el.name);
    setPickerColor({ color: el.color, background: el.background });
  };
  return /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(RadioInputWrapper, { children: colorPicker.map((el) => /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)(RadioLabel, { children: [
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(
      RadioInput,
      {
        name: el.name,
        value: el.name,
        checked: selectedOption === el.name,
        onClick: () => {
          handleOptionChange(el);
        },
        disabled: false
      }
    ),
    selectedOption === el.name ? /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(CheckedRadioIcon, { style: { backgroundColor: `${el.color}` } }) : /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(RadioIcon, { style: { backgroundColor: `${el.color}` } })
  ] }, el.name)) });
};

// src/ui-kit/Form/Form.styles.ts
var import_styled_components8 = __toESM(require("styled-components"));
var import_rc_field_form = __toESM(require("rc-field-form"));
var StyledForm = (0, import_styled_components8.default)(import_rc_field_form.default)`
  display: flex;
  flex-direction: column;
  gap: 12px;
  justify-self: flex-start;
`;

// src/ui-kit/Form/Form.tsx
var import_jsx_runtime9 = require("react/jsx-runtime");
var Form = ({ children, ...props }) => {
  return /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(StyledForm, { ...props, children });
};

// src/UbaWidget.tsx
var import_rc_field_form2 = require("rc-field-form");
var import_dayjs = __toESM(require("dayjs"));

// src/api/cohort.api.ts
var getCohorts = (appName) => {
  return api.get("cohort", {
    params: {
      appName
    }
  }).then((response) => {
    return response.data;
  });
};
var postCohort = ({
  appName,
  name,
  color,
  filters,
  background
}) => {
  return api.post("cohort", {
    name,
    color,
    background,
    filters,
    appName
  });
};
var deleteCohort = (cohort_id) => {
  return api.delete(`cohort/${cohort_id}`);
};

// src/UbaWidget.tsx
var import_jsx_runtime10 = require("react/jsx-runtime");
var UbaWidget = ({ appName }) => {
  const [dateOption, setDateOption] = (0, import_react5.useState)("");
  const { data: appEvents, mutate: mutateAppEvents } = (0, import_swr.default)(
    ["/application", appName, dateOption],
    ([, appId, date]) => getApplication(appId, date)
  );
  const { data: cohorts, mutate: mutateCohorts } = (0, import_swr.default)(
    ["/cohorts", appName],
    ([, cAppName]) => getCohorts(cAppName)
  );
  const [menuOpen, setMenuOpen] = (0, import_react5.useState)(false);
  const [tooltipEvents, setTooltipEvents] = (0, import_react5.useState)([]);
  const [maxHeat, setMaxHeat] = (0, import_react5.useState)(0);
  const [totalClicks, setTotalClicks] = (0, import_react5.useState)(0);
  const [flagAddCohort, setFlagAddCohort] = (0, import_react5.useState)(false);
  const [selectedCohortsTags, setSelectedCohortsTags] = (0, import_react5.useState)(
    []
  );
  const selectedCohorts = (0, import_react5.useMemo)(() => {
    if (!cohorts)
      return [];
    return cohorts.filter(
      (item) => selectedCohortsTags.includes(item?.cohort_id)
    );
  }, [selectedCohortsTags]);
  const [pickerColor, setPickerColor] = (0, import_react5.useState)({
    color: "#754AEE",
    background: "rgba(117,74,238,0.12)"
  });
  const [valueCohortInput, setValueCohort] = (0, import_react5.useState)("");
  const location = (0, import_react_router_dom.useLocation)();
  const dates = (0, import_react5.useMemo)(
    () => ({
      day_ago: (0, import_dayjs.default)().subtract(1, "day").toString(),
      week_ago: (0, import_dayjs.default)().subtract(1, "week").toString(),
      month_ago: (0, import_dayjs.default)().subtract(1, "month").toString(),
      all_time: ""
    }),
    []
  );
  const [form] = (0, import_rc_field_form2.useForm)();
  const closeWidgetHandler = (e) => {
    if (e.key !== "Escape")
      return;
    setMenuOpen(false);
  };
  const addCohort = () => {
    if (!valueCohortInput)
      return;
    const searchString = Object.entries(form.getFieldsValue()).reduce(
      (acc, [key, value]) => {
        if (!value)
          return acc;
        if (!acc) {
          acc = `${key}=${value}`;
        } else {
          acc = `${acc}&${key}=${value}`;
        }
        return acc;
      },
      ""
    );
    postCohort({
      appName,
      name: valueCohortInput.trim(),
      color: pickerColor.color,
      background: pickerColor.background,
      filters: {
        search: searchString
      }
    }).then(() => {
      mutateAppEvents();
      mutateCohorts();
      form.setFieldsValue({
        utm_source: "",
        utm_campaign: "",
        utm_medium: "",
        utm_content: "",
        utm_term: ""
      });
      setFlagAddCohort(false);
      setPickerColor({
        color: "#754AEE",
        background: "rgba(117,74,238,0.12)"
      });
      setValueCohort("");
    });
  };
  const changeInput = (e) => {
    setValueCohort(e.target.value);
  };
  const deleteTag = (id) => {
    deleteCohort(id).then(() => {
      mutateCohorts();
    });
  };
  (0, import_react5.useEffect)(() => {
    if (!appEvents || !cohorts)
      return;
    const parsedData = appEvents?.sessions.reduce((acc, session) => {
      for (const event of session.events) {
        if (location.pathname !== event.data.page)
          return acc;
        const selector = `${event?.data.selector}`;
        if (selectedCohorts.length) {
          selectedCohorts.map((cohort) => {
            const isCohortMatchSession = JSON.stringify(cohort.filters.search.split("&").sort()) === JSON.stringify(session.searchString.split("&").sort());
            if (isCohortMatchSession) {
              acc[`${selector}`] = acc[`${selector}`] ? acc[`${selector}`] : {};
              acc[`${selector}`][`${cohort.name}`] = {
                clicks: acc[`${selector}`]?.[`${cohort.name}`] ? ++acc[`${selector}`][`${cohort.name}`].clicks : 1,
                color: cohort.color
              };
            }
          });
        } else {
          acc[`${selector}`] = acc[`${selector}`] ? acc[`${selector}`] : {};
          acc[`${selector}`].uba_without_cohorts = {
            clicks: acc[`${selector}`]?.uba_without_cohorts ? ++acc[`${selector}`].uba_without_cohorts.clicks : 1,
            color: `#EB4E27`
          };
        }
      }
      return acc;
    }, {});
    setTooltipEvents(parsedData);
    setMaxHeat(Math.max(...Object.values(parsedData)));
    setTotalClicks(
      Object.values(parsedData).reduce(
        (acc, curr) => acc + Object.values(curr).reduce((acc2, v) => {
          acc2 += v.clicks;
          return acc2;
        }, 0),
        0
      )
    );
  }, [location, appEvents, selectedCohorts, cohorts]);
  (0, import_react5.useEffect)(() => {
    document.addEventListener("keydown", closeWidgetHandler);
    return () => {
      document.removeEventListener("keydown", closeWidgetHandler);
    };
  }, []);
  return (0, import_react_dom.createPortal)(
    /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(import_jsx_runtime10.Fragment, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
        StyledUbaWidget,
        {
          src: logo_default,
          onClick: () => {
            setMenuOpen(true);
          }
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(StyledDrawer, { visible: menuOpen, children: [
        /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(DrawerHeader, { children: [
          /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(DrawerLogo, { src: logoHeader_default }),
          /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
            DrawerCloser,
            {
              onClick: () => {
                setMenuOpen(false);
              },
              src: close_widget_default
            }
          )
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(DrawerBody, { children: [
          /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
            TagGroup,
            {
              selectable: {
                selectedTags: selectedCohortsTags,
                setSelectedTags: setSelectedCohortsTags
              },
              tags: cohorts || [],
              flagCohort: setFlagAddCohort,
              deleteTag
            }
          ),
          /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
            Segmented,
            {
              small: true,
              stretch: true,
              currentValue: dateOption,
              onChange: setDateOption,
              name: "uba_widget_date",
              radios: [
                { label: "1 \u0434.", value: dates.day_ago },
                { label: "7 \u0434.", value: dates.week_ago },
                {
                  label: "30 \u0434.",
                  value: dates.month_ago
                },
                { label: "\u0412\u0441\u0435", value: dates.all_time }
              ]
            }
          ),
          flagAddCohort && /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(Form, { form, style: { alignSelf: "stretch" }, children: [
            /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(import_rc_field_form2.Field, { name: "utm_source", children: /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
              Input,
              {
                defaultValue: "",
                style: { alignSelf: "stretch" },
                stretch: true,
                label: "utm_source"
              }
            ) }),
            /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(import_rc_field_form2.Field, { name: "utm_medium", children: /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
              Input,
              {
                defaultValue: "",
                style: { alignSelf: "stretch" },
                stretch: true,
                label: "utm_medium"
              }
            ) }),
            /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(import_rc_field_form2.Field, { name: "utm_content", children: /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
              Input,
              {
                defaultValue: "",
                style: { alignSelf: "stretch" },
                stretch: true,
                label: "utm_content"
              }
            ) }),
            /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(import_rc_field_form2.Field, { name: "utm_campaign", children: /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
              Input,
              {
                defaultValue: "",
                style: { alignSelf: "stretch" },
                stretch: true,
                label: "utm_campaign"
              }
            ) }),
            /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(import_rc_field_form2.Field, { name: "utm_term", children: /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
              Input,
              {
                defaultValue: "",
                style: { alignSelf: "stretch" },
                stretch: true,
                label: "utm_term"
              }
            ) })
          ] }),
          flagAddCohort && /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(StyledContainerSelectColor, { children: [
            /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
              Input,
              {
                stretch: true,
                label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u043A\u043E\u0433\u043E\u0440\u0442\u044B",
                placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435",
                onChange: changeInput,
                value: valueCohortInput
              }
            ),
            /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(SelectColor, { setPickerColor }),
            /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(Button, { type: "submit", onClick: addCohort, pattern: "primary", children: "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043A\u043E\u0433\u043E\u0440\u0442\u0443" })
          ] })
        ] })
      ] }),
      menuOpen && /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
        Tooltips,
        {
          highestValue: maxHeat,
          events: tooltipEvents,
          totalClicks
        }
      )
    ] }),
    document.body
  );
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  UbaWidget
});
