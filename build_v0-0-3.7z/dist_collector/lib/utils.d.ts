import { eventWithTime } from "@rrweb/types";
interface IUtmMarks {
    utm_source: string;
    utm_campaign: string;
    utm_term: string;
    utm_medium: string;
    utm_content: string;
}
export declare const getUtmMarks: () => IUtmMarks;
export declare const getUrl: (str: string | any) => string;
export declare function Singleton<T extends new (...args: Array<any>) => any>(WrappedClass: T): T;
export interface IEvent {
    type: string;
    data: object;
}
export interface IMessage {
    url: string;
    utm: Record<string, string>;
    imageSource: string;
    hrefLocation: string;
    events: Array<IEvent>;
    pageTitle: string;
    eventsReplay: Array<eventWithTime>;
}
export declare const generateSelector: (context: any) => string;
export {};
