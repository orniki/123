interface IRecorderOptions {
    applicationName: string;
    applicationVersion: string;
    eventsLength?: number;
    title?: string;
}
export declare const useRecorder: ({ applicationName, applicationVersion, eventsLength, title, }: IRecorderOptions) => void;
export {};
