import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { PassportModule } from '@nestjs/passport';
import { MailModule } from '@modules/mail/mail.module';
import { UserModule } from '@modules/user/User.module';
import { AuthModule } from '@modules/auth/Auth.module';
import { WidgetModule } from './common/modules/widget/Widget.module';
import { ThrottlerModule } from '@nestjs/throttler';

@Module({
  imports: [
    ConfigModule.forRoot(),
    ThrottlerModule.forRoot({
      ttl: 60,
      limit: 20,
    }),
    MailModule,
    PassportModule,
    AuthModule,
    UserModule,
    WidgetModule,
  ],
})
export class AppModule {}
