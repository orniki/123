import { NestFactory } from '@nestjs/core';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { AppModule } from './app.module';
import {
  FastifyAdapter,
  NestFastifyApplication,
} from '@nestjs/platform-fastify';
import { ValidationPipe, VersioningType } from '@nestjs/common';

const appPort = process.env.PORT || 3000;

async function bootstrap() {
  const app = await NestFactory.create<NestFastifyApplication>(
    AppModule,
    new FastifyAdapter({ bodyLimit: 102400000 }),
  );

  app.useGlobalPipes(new ValidationPipe({ whitelist: true }));

  const APP_ROUTE_PREFIX = 'api';

  app.enableCors();

  app
    .enableVersioning({
      type: VersioningType.URI,
      defaultVersion: '1',
    })
    .setGlobalPrefix(APP_ROUTE_PREFIX);

  if (process.env.NODE_ENV !== 'production') {
    const config = new DocumentBuilder()
      .setTitle('Uba-tool API')
      .setDescription(`Uba-tool API, base url : ${process.env.BASE_URL}`)
      .setVersion('0.0.1')
      .addBearerAuth()
      .addSecurity('api-key', {
        type: 'http',
        scheme: 'Api-Key',
      })
      .build();

    const document = SwaggerModule.createDocument(app, config);
    SwaggerModule.setup(`${APP_ROUTE_PREFIX}/:version/swagger`, app, document);
  }

  await app.listen(appPort, '0.0.0.0', (e, address) => {
    console.log(
      '\x1b[44m',
      `⚡ Awesome! Server is running on: ${address}`,
      '\x1b[0m',
    );
  });
}

void bootstrap();
