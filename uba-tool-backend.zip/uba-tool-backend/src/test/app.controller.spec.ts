import { Test, TestingModule } from '@nestjs/testing';
import { SessionController } from '@common/modules/session/Session.controller';
import { SessionService } from '@common/modules/session/Session.service';

describe('AppController', () => {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  let sessionController: SessionController;

  beforeEach(async () => {
    const app: TestingModule = await Test.createTestingModule({
      controllers: [SessionController],

      providers: [SessionService],
    }).compile();

    sessionController = app.get<SessionController>(SessionController);
  });

  describe('root', () => {
    it('should return "Hello World!"', () => {
      expect('Hello World!').toBe('Hello World!');
    });
  });
});
