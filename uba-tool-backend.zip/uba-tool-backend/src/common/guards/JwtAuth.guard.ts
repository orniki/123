import { AuthHelper } from '@/shared/helpers/Auth.helper';
import { ExecutionContext, Inject, Injectable } from '@nestjs/common';
import { AuthGuard, IAuthGuard } from '@nestjs/passport';
import { User } from '@prisma/client';

@Injectable()
export class LegacyJwtGuard extends AuthGuard('jwt') implements IAuthGuard {
  @Inject(AuthHelper) helper: AuthHelper;

  public async canActivate(context: ExecutionContext): Promise<boolean> {
    await super.canActivate(context);

    const jwtToken = context.switchToHttp().getRequest().headers.authorization;

    let user: User = null;
    if (jwtToken) {
      const token = jwtToken.substring(7);
      if (await this.helper.validate(token)) {
        user = await this.helper.decode(token);
      }
    }

    return !!user?.user_id;
  }
}
