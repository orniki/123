import { ApiProperty } from '@nestjs/swagger';

export class BadRequestErrorDto {
  @ApiProperty({ example: 400 })
  statusCode: number;

  @ApiProperty({ example: 'Неправильный запрос' })
  message: string;
}

export class UnauthorizedErrorDto {
  @ApiProperty({ example: 401 })
  statusCode: number;

  @ApiProperty({ example: 'Ошибка авторизации' })
  message: string;
}

export class PaymentErrorDto {
  @ApiProperty({ example: 402 })
  statusCode: number;

  @ApiProperty({ example: 'Необходима оплата' })
  message: string;
}

export class ForbiddenErrorDto {
  @ApiProperty({ example: 403 })
  statusCode: number;

  @ApiProperty({ example: 'Отказано в доступе' })
  message: string;
}

export class BadRequestDto {
  @ApiProperty({ example: 404 })
  statusCode: number;

  @ApiProperty({ example: 'Страница не найдена' })
  message: string;
}

export class MethodNotAllowedErrorDto {
  @ApiProperty({ example: 405 })
  statusCode: number;

  @ApiProperty({ example: 'Недопустимый метод' })
  message: string;
}

export class ConflictErrorDto {
  @ApiProperty({ example: 400 })
  statusCode: number;

  @ApiProperty({ example: 'Запись уже создана' })
  message: string;
}

export class TooManyRequestErrorDto {
  @ApiProperty({ example: 429 })
  statusCode: number;

  @ApiProperty({ example: 'Слишком много запросов' })
  message: string;
}
