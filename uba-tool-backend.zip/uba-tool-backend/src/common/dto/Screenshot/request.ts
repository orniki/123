import { ApiProperty } from '@nestjs/swagger';
import { IsNumberString, IsUrl } from 'class-validator';

export class ScreenshotQuery {
  @ApiProperty()
  @IsUrl()
  url: string;

  @ApiProperty()
  @IsNumberString()
  width: string;

  @ApiProperty()
  @IsNumberString()
  height: string;
}
