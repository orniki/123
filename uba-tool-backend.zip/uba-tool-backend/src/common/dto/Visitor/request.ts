import { ApiProperty } from '@nestjs/swagger';
import {
  IsDate,
  IsNumber,
  IsNumberString,
  IsOptional,
  IsString,
} from 'class-validator';

export class createVisitorBody {
  @ApiProperty({ example: 1 })
  @IsOptional()
  @IsNumber()
  visitor_id: number;

  @ApiProperty({ example: 'unique_string' })
  @IsString()
  uba_id: string;

  @ApiProperty({ example: 1 })
  @IsNumber()
  applicationId: number;

  @ApiProperty({ example: new Date('1970') })
  @IsOptional()
  @IsDate()
  first_visit: Date;

  @ApiProperty({ example: new Date('1999') })
  @IsOptional()
  @IsDate()
  last_visit?: Date;

  @ApiProperty({ example: 53 })
  @IsOptional()
  @IsNumber()
  total_events?: number;

  @ApiProperty({ example: 91 })
  @IsOptional()
  @IsNumber()
  total_clicks?: number;

  @ApiProperty({ example: 12 })
  @IsOptional()
  @IsNumber()
  total_sessions?: number;
}

export class getAllVisitorsQuery {
  @ApiProperty({ example: '1' })
  @IsNumberString()
  app_id: string;

  @ApiProperty({ example: '10', description: 'Сколько записей в странице' })
  @IsNumberString()
  limit: string;

  @ApiProperty({ example: '2', description: 'Сколько страниц пропустить' })
  @IsNumberString()
  page: string;

  @ApiProperty({
    example: 'uba_id;test@mail.ru',
    required: false,
    description: 'Строка вида "ключ;значение"',
  })
  @IsOptional()
  @IsString()
  search?: string;
}
