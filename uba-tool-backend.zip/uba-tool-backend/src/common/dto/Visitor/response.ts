import { ApiProperty } from '@nestjs/swagger';

export class NotFoundVisitorResponse {
  @ApiProperty({ example: 404 })
  statusCode: number;

  @ApiProperty({ example: 'Посетитель не найден' })
  message: string;
}

export class ForbiddenVisitorResponse {
  @ApiProperty({ example: 403 })
  statusCode: number;

  @ApiProperty({ example: 'Вы не имеете доступа к приложению' })
  message: string;
}

export class getAllVisitorsResponse {
  @ApiProperty({
    example: { total_visitors: 123, current_page: 2, per_page: 10 },
  })
  page_info: object;

  @ApiProperty({
    example: {
      visitor_id: 4,
      uba_id: 'unique_id',
      applicationId: 1,
      first_visit: new Date('2022'),
      last_visit: new Date('2023'),
      total_events: 400,
      total_clicks: 120,
      total_sessions: 21,
    },
  })
  visitors: Array<any>;
}
