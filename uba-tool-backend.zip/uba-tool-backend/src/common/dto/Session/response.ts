import { ApiProperty } from '@nestjs/swagger';
import { Visitor } from '@prisma/client';

export class SessionsByUser {
  @ApiProperty({
    example: {
      total_sessions: 12,
      current_page: 1,
      per_page: 10,
    },
  })
  page_info: object;

  @ApiProperty({
    example: [
      {
        sessionId: 2,
        createdAt: new Date('2022'),
        endedAt: new Date('2022'),
        ip_address: '127.0.0.1',
        device: 'Android',
        platform: 'web',
        browser: 'Chrome',
        recorder_version: '0.0.26',
        agent_language: 'en-us',
        country: 'Russia',
        city: 'Severomorsk',
        Event: [
          {
            type: 'click',
            custom_type: 'login',
            createdAt: new Date('2023'),
          },
        ],
      },
    ],
  })
  sessions: Array<any>;
}

export class getAllSessions {
  @ApiProperty({
    example: { total_sessions: 192, current_page: 4, per_page: 10 },
  })
  page_info: object;

  @ApiProperty({
    example: [
      {
        sessionId: 1,
        Visitor: {
          visitor_id: 1,
          uba_id: 'test@gmail.com',
          name: 'Maxim',
          first_visit: new Date(2022),
          last_visit: new Date(2023),
          total_events: 600,
          total_clicks: 1782,
          total_sessions: 59,
        },
        createdAt: new Date('2022'),
        endedAt: new Date('2023'),
        _count: {
          Event: 214,
        },
      },
    ],
  })
  sessions: Array<any>;
}

export class getSessionResponse {
  @ApiProperty({ example: 1 })
  sessionId: number;

  @ApiProperty({ example: 1 })
  appId: number;

  @ApiProperty({ example: new Date('2022') })
  createdAt: Date;

  @ApiProperty({ example: new Date('2023') })
  endedAt: Date;

  @ApiProperty()
  utm: object;

  @ApiProperty({
    example: [
      {
        type: 'click',
        customEvent: {
          eventId: 'Login',
          htmlEvent: 'click',
          pattern: 'success',
          properties: {},
        },
      },
    ],
    description: 'Лучше использовать модель Event',
  })
  events: any;

  @ApiProperty({ example: 'Uba tool' })
  pageTitle: string;

  @ApiProperty({ example: new Date('2022') })
  updated: Date;

  @ApiProperty({ example: 'data:image/jpeg;base64, LzlqLzRBQ... ' })
  imageSource: string;

  @ApiProperty({
    description:
      'Тип canvasEventsWithTime из rrweb/types. Просто вставить в реплей',
  })
  eventsReplay: Array<any>;

  @ApiProperty({ example: 'https://uba-tool.api.ru' })
  hrefLocation: string;

  @ApiProperty({ example: '?utm_source=yandex&utm_campaign=google' })
  searchString: string;

  @ApiProperty({ example: ['sidebar', 'header'] })
  feature: Array<string>;

  @ApiProperty({ example: 'yandex' })
  utm_source: string;

  @ApiProperty({ example: 'yandex_campaign' })
  utm_campaign: string;

  @ApiProperty({ example: 'medium' })
  utm_medium: string;

  @ApiProperty({ example: 'terminus' })
  utm_term: string;

  @ApiProperty({ example: 'contentus' })
  utm_content: string;

  @ApiProperty({ example: 'dev' })
  environment: string;

  @ApiProperty({ example: '185.185.69.1' })
  ip_address: string | null;

  @ApiProperty({ example: 'Android' })
  device: string | null;

  @ApiProperty({ example: 'Web' })
  platform: string | null;

  @ApiProperty({ example: 'Chrome' })
  browser: string | null;

  @ApiProperty({ example: '0.0.26' })
  recorder_version: string | null;

  @ApiProperty({ example: 'en-us' })
  agent_language: string | null;

  @ApiProperty({ example: 'Russia' })
  country: string | null;

  @ApiProperty({ example: 'Severomorsk' })
  city: string | null;

  @ApiProperty({
    example: [
      {
        type: 'click',
        custom_type: 'login',
        createdAt: new Date('2023'),
      },
    ],
    isArray: true,
  })
  Event: {
    type: string;
    custom_type: string | null;
    createdAt: Date;
  };

  @ApiProperty({
    example: {
      visitor_id: 1,
      uba_id: 'test@gmail.com',
      applicationId: 1,
      first_visit: new Date('2022'),
      last_visit: new Date('2023'),
      total_events: 53,
      total_clicks: 91,
      total_sessions: 12,
    },
  })
  Visitor: Visitor;
}
