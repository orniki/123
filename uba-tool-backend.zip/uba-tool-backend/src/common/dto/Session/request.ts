import { canvasEventWithTime } from '@rrweb/types';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsArray,
  IsDateString,
  IsJSON,
  IsNumber,
  IsNumberString,
  IsObject,
  IsOptional,
  IsString,
} from 'class-validator';
import { IEvents } from '@/common/types/Session.types';

export class pushSessionBody {
  @ApiProperty()
  @IsNumber()
  appId: number;

  @ApiProperty()
  @IsString()
  searchString: string;

  @ApiProperty()
  @IsString()
  origin: string;

  @ApiProperty()
  @IsObject()
  utm: object;

  @ApiProperty()
  @IsString()
  utm_source: string;

  @ApiProperty()
  @IsString()
  utm_campaign: string;

  @ApiProperty()
  @IsString()
  utm_medium: string;

  @ApiProperty()
  @IsString()
  utm_content: string;

  @ApiProperty()
  @IsString()
  utm_term: string;

  @ApiProperty()
  @IsArray()
  events: Array<any>;

  @ApiProperty()
  @IsString()
  pageTitle: string;

  @ApiProperty()
  @IsArray()
  eventsReplay: Array<any>;

  @ApiProperty()
  @IsString()
  hrefLocation: string;

  @ApiProperty()
  @IsString()
  platform: string;

  @ApiProperty()
  @IsString()
  browser: string;

  @ApiProperty()
  @IsString()
  device: string;

  @ApiProperty()
  @IsString()
  recorder_version: string;

  @ApiProperty()
  @IsString()
  agent_language: string;

  @ApiProperty()
  @IsOptional()
  @IsString()
  environment?: string;

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  visitor_id?: number;

  @ApiProperty()
  @IsOptional()
  @IsArray()
  features?: Array<string>;
}

export class CreateSessionBody {
  @ApiProperty()
  @IsJSON()
  @IsObject()
  utm: {
    utm_source: string;
    utm_content: string;
    utm_medium: string;
    utm_campaign: string;
    utm_term: string;
  };

  @ApiProperty()
  @IsArray()
  events: Array<IEvents>;

  @ApiProperty()
  @IsDateString()
  updated: Date;

  @ApiProperty()
  @IsString()
  pageTitle: string;

  @ApiProperty()
  @IsString()
  imageSource: string;

  @ApiProperty()
  @IsArray()
  eventsReplay: Array<canvasEventWithTime>;

  @ApiProperty()
  @IsString()
  hrefLocation: string;

  @ApiProperty()
  @IsString()
  appId: string;

  @ApiProperty()
  @IsString()
  environment?: string;
}

export class CreateChunkBody {
  @ApiProperty()
  @IsNumber()
  id: number;

  @ApiProperty()
  @IsArray()
  events: Array<IEvents>;
}

export class reqFilterQuery {
  @ApiProperty()
  @IsString()
  site: string;

  @ApiProperty()
  @IsNumberString()
  page?: number;

  @ApiProperty()
  @IsNumberString()
  limit?: number;

  @ApiProperty()
  @IsString()
  searchString?: string;
}

export class getSessionsByVisitorQuery {
  @ApiProperty({ example: '1' })
  @IsNumberString()
  app_id: string;

  @ApiProperty({ example: '1' })
  @IsNumberString()
  visitor_id: string;

  @ApiProperty({ example: '10' })
  @IsNumberString()
  limit: string;

  @ApiProperty({ example: '1' })
  @IsNumberString()
  page: string;

  @ApiProperty({
    example: 'session;test@mail.ru',
    required: false,
    description: 'Строка вида "ключ;значение"',
  })
  @IsOptional()
  @IsString()
  search?: string;
}

export class getAllSessionsQuery {
  @ApiProperty({ example: '1' })
  @IsNumberString()
  app_id: string;

  @ApiProperty({ example: '10' })
  @IsNumberString()
  limit: string;

  @ApiProperty({ example: '1' })
  @IsNumberString()
  page: string;

  @ApiProperty({
    example: 'session;test@mail.ru',
    required: false,
    description: 'Строка вида "ключ;значение"',
  })
  @IsOptional()
  @IsString()
  search?: string;
}
