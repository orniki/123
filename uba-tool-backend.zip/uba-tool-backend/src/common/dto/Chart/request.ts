import { ApiProperty } from '@nestjs/swagger';
import {
  IsArray,
  IsDateString,
  IsNumber,
  IsNumberString,
  IsObject,
  IsOptional,
  IsString,
  Length,
} from 'class-validator';

export enum CHART_PATTERN {
  bar = 'bar',
  line = 'line',
  tiny_line = 'tiny_line',
  vertical_line = 'vertical_line',
  biaxial_line = 'biaxial_line',
}

export class createChartBody {
  @ApiProperty({ example: 'Awesome title' })
  @IsString()
  @Length(1, 60)
  title: string;

  @ApiProperty({
    example: [
      { type: 'click', pattern: 'total' },
      { custom_type: 'login', pattern: 'total' },
    ],
  })
  @IsArray()
  events: any;

  @ApiProperty({ example: 1 })
  @IsNumber()
  dashboard_id: number;

  @ApiProperty({ example: 'bar' })
  @IsString()
  pattern: string;

  @ApiProperty({
    example: {
      A: {
        utm_source: {
          filter: 'contains',
          value: 'vk',
        },
        utm_campaign: {
          filter: 'startsWith',
          value: 'tg',
        },
      },
      B: {
        ip_address: {
          filter: 'startsWith',
          value: '192',
        },
      },
      C: {
        utm_content: {
          filter: 'startsWith',
          value: 're',
        },
      },
    },
  })
  @IsOptional()
  @IsObject()
  filters?: any;

  @ApiProperty({ example: 'A && (B || C)' })
  @IsOptional()
  @IsString()
  relation?: string;
}

export class updateChartBody {
  @ApiProperty({ example: 'Awesome title', required: false })
  @IsOptional()
  @IsString()
  title?: string;

  @ApiProperty({
    example: [
      { type: 'click', pattern: 'total' },
      { custom_type: 'login', pattern: 'total' },
    ],
    required: false,
  })
  @IsOptional()
  @IsArray()
  events?: any;

  @ApiProperty({ example: 1, required: false })
  @IsOptional()
  @IsNumber()
  dashboard_id?: number;

  @ApiProperty({ example: 'bar', required: false })
  @IsOptional()
  @IsString()
  pattern?: string;

  @ApiProperty({
    example: {
      A: {
        utm_source: {
          filter: 'contains',
          value: 'vk',
        },
        utm_campaign: {
          filter: 'startsWith',
          value: 'tg',
        },
      },
      B: {
        ip_address: {
          filter: 'startsWith',
          value: '192',
        },
      },
      C: {
        utm_content: {
          filter: 'startsWith',
          value: 're',
        },
      },
    },
    required: false,
  })
  @IsOptional()
  @IsObject()
  filters?: any;

  @ApiProperty({
    example: 'A && (B || C)',
    required: false,
    description: 'Если есть филтры - обязательно для заполнения',
  })
  @IsOptional()
  @IsString()
  relation?: string;
}

export class getAllChartsQuery {
  @ApiProperty({ example: '1' })
  @IsNumberString()
  dashboardId: string;

  @ApiProperty({ example: new Date('2022-03-10').toString(), required: false })
  @IsOptional()
  @IsDateString()
  from_date?: string;

  @ApiProperty({ example: new Date('2022-03-17').toString(), required: false })
  @IsOptional()
  @IsDateString()
  to_date?: string;
}

export class getChartQuery {
  @ApiProperty({ example: new Date('2022-03-10').toString(), required: false })
  @IsOptional()
  @IsDateString()
  from_date?: string;

  @ApiProperty({ example: new Date('2022-03-17').toString(), required: false })
  @IsOptional()
  @IsDateString()
  to_date?: string;
}

export class chartPreviewQuery {
  @ApiProperty({ example: new Date('2022-03-10').toString(), required: false })
  @IsOptional()
  @IsDateString()
  from_date?: string;

  @ApiProperty({ example: new Date('2022-03-17').toString(), required: false })
  @IsOptional()
  @IsDateString()
  to_date?: string;

  @ApiProperty({ example: '1', required: true })
  @IsOptional()
  @IsNumberString()
  appId?: string;
}

export class chartDayPreviewQuery {
  @ApiProperty({ example: '2023-05-12T00:00:00.000' })
  @IsDateString()
  date: string;

  @ApiProperty({ example: '1', required: true })
  @IsNumberString()
  appId: string;
}

export class chartWithoutDataResponse {
  @ApiProperty({ example: 3 })
  chart_id: number;

  @ApiProperty({ example: 3 })
  dashboard_id: number;

  @ApiProperty({ example: 'bar' })
  pattern: 'bar';

  @ApiProperty({
    example: {
      A: {
        utm_source: {
          filter: 'contains',
          value: 'vk',
        },
        utm_campaign: {
          filter: 'startsWith',
          value: 'tg',
        },
      },
      B: {
        IP: {
          filter: 'startsWith',
          value: '192',
        },
      },
    },
  })
  filters?: any;

  @ApiProperty({ example: 'A || B' })
  relation?: string;

  @ApiProperty({ example: 'Awesome chart' })
  title: string;

  @ApiProperty({
    example: [
      {
        type: 'mousemove',
        pattern: 'total',
      },
      {
        pattern: 'total',
        custom_type: 'checkme',
      },
      {
        type: 'click',
        pattern: 'total',
      },
    ],
  })
  events: any;

  @ApiProperty({ example: [1, 2, 3] })
  usersAllowList: Array<number>;

  @ApiProperty({ example: 1 })
  owner: number;

  @ApiProperty({
    example: [{ email: 'flamekodanf@gmail.com', event: 'created', user_id: 1 }],
  })
  modify_history: any;
}
