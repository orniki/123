import { ApiProperty } from '@nestjs/swagger';

export class getChartResponse {
  @ApiProperty({ example: 'chart_3' })
  position_id: string;

  @ApiProperty({
    example: {
      chart_id: 3,
      dashboard_id: 3,
      pattern: 'bar',
      filters: null,
      title: 'Awesome chart',
      events: [
        {
          type: 'mousemove',
          pattern: 'total',
        },
        {
          pattern: 'total',
          custom_type: 'checkme',
        },
        {
          type: 'click',
          pattern: 'total',
        },
      ],
      usersAllowList: [],
      owner: 1,
      modify_history: [
        {
          email: 'flamekodanf@gmail.com',
          event: 'created',
          user_id: 1,
        },
      ],
      createdAt: '2023-04-27T15:07:30.954Z',
    },
  })
  chart: any;

  @ApiProperty({
    example: [
      {
        name: '20-04-2023',
        mousemove: 0,
        checkme: 0,
        click: 0,
      },
      {
        name: '21-04-2023',
        mousemove: 0,
        checkme: 0,
        click: 0,
      },
      {
        name: '22-04-2023',
        mousemove: 0,
        checkme: 0,
        click: 0,
      },
      {
        name: '23-04-2023',
        mousemove: 0,
        checkme: 0,
        click: 0,
      },
      {
        name: '24-04-2023',
        mousemove: 0,
        checkme: 0,
        click: 0,
      },
      {
        name: '25-04-2023',
        mousemove: 159,
        checkme: 11,
        click: 24,
      },
      {
        name: '26-04-2023',
        mousemove: 0,
        checkme: 0,
        click: 0,
      },
      {
        name: '27-04-2023',
        mousemove: 0,
        checkme: 0,
        click: 0,
      },
    ],
  })
  data: any;
}

export class chartDataResponse {
  @ApiProperty({ example: '20-04-2022' })
  name: string;

  @ApiProperty({ example: 123 })
  some_event: number;
}

export class getDayChartResponse {
  @ApiProperty({ example: 'chart_3' })
  position_id: string;

  @ApiProperty({
    example: {
      chart_id: 5,
      dashboard_id: 3,
      pattern: 'bar',
      filters: null,
      relation: null,
      title: 'Clicks withou filters (changed)',
      events: [
        {
          type: 'click',
          pattern: 'total',
        },
      ],
      usersAllowList: [],
      owner: 1,
      modify_history: [
        {
          email: 'flamekodanf@gmail.com',
          event: 'created',
          user_id: 1,
        },
      ],
      createdAt: '2023-04-27T18:48:52.981Z',
    },
  })
  chart: any;

  @ApiProperty({
    example: [
      {
        name: '00:00',
        click: 0,
      },
      {
        name: '01:00',
        click: 0,
      },
      {
        name: '02:00',
        click: 0,
      },
      {
        name: '03:00',
        click: 0,
      },
      {
        name: '04:00',
        click: 0,
      },
      {
        name: '05:00',
        click: 0,
      },
      {
        name: '06:00',
        click: 0,
      },
      {
        name: '07:00',
        click: 0,
      },
      {
        name: '08:00',
        click: 0,
      },
      {
        name: '09:00',
        click: 0,
      },
      {
        name: '10:00',
        click: 0,
      },
      {
        name: '11:00',
        click: 36,
      },
      {
        name: '12:00',
        click: 0,
      },
      {
        name: '13:00',
        click: 0,
      },
      {
        name: '14:00',
        click: 0,
      },
      {
        name: '15:00',
        click: 28,
      },
      {
        name: '16:00',
        click: 82,
      },
      {
        name: '17:00',
        click: 0,
      },
      {
        name: '18:00',
        click: 114,
      },
      {
        name: '19:00',
        click: 0,
      },
      {
        name: '20:00',
        click: 0,
      },
      {
        name: '21:00',
        click: 0,
      },
      {
        name: '22:00',
        click: 0,
      },
      {
        name: '23:00',
        click: 0,
      },
    ],
  })
  data: any;
}
