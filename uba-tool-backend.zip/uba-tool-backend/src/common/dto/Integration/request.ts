import { ApiProperty } from '@nestjs/swagger';
import { IsNumberString, IsString } from 'class-validator';

export class postBitrixLeadBody {
  @ApiProperty()
  @IsString()
  bitrixUrl: string;

  @ApiProperty()
  @IsNumberString()
  authID: string;

  @ApiProperty()
  @IsString()
  authKey: string;

  @ApiProperty()
  @IsNumberString()
  sessionID: string;
}
