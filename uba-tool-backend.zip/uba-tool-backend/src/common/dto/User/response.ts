import { ApiProperty } from '@nestjs/swagger';
import { USER_TARRIFF } from '@prisma/client';

export class UserOkResponse {
  @ApiProperty({ example: 'ubatool@gmail.com' })
  email: string;

  @ApiProperty({ example: 'Ivan' })
  name: string;

  @ApiProperty({ example: 'Ivanov' })
  surname: string;

  @ApiProperty({ example: true })
  activated: boolean;

  @ApiProperty({ example: 'FREE' })
  tariff: USER_TARRIFF;

  @ApiProperty({ example: 'your@email.ru.1aHVuwNwzITpzJWl40OPvx' })
  apiKey: string;
}
