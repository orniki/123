import { ApiProperty } from '@nestjs/swagger';
import { IsString, Length } from 'class-validator';

export class changePasswordBody {
  @ApiProperty()
  @IsString()
  @Length(8, 24)
  new_password: string;

  @ApiProperty()
  @IsString()
  old_password: string;
}
