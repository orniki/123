import { ApiProperty } from '@nestjs/swagger';
import { COHORT_COLOR } from '@prisma/client';
import {
  IsArray,
  IsEnum,
  IsHexColor,
  IsNumber,
  IsNumberString,
  IsObject,
  IsOptional,
  IsRgbColor,
  IsString,
  Length,
} from 'class-validator';

export class getCohortsQuery {
  @ApiProperty({ example: '1' })
  @IsNumberString()
  appId: string;
}

export class updateCohortsQuery {
  @ApiProperty({ example: '1' })
  @IsNumberString()
  appId: string;
}

export class deleteCohortsQuery {
  @ApiProperty({ example: '1' })
  @IsNumberString()
  appId: string;
}

export class createCohortBody {
  @ApiProperty({ example: 'My cohort' })
  @IsString()
  @Length(1, 20)
  title: string;

  @ApiProperty({ example: COHORT_COLOR.bittersweet })
  @IsOptional()
  @IsEnum(COHORT_COLOR)
  theme?: COHORT_COLOR;

  @ApiProperty({ example: '#FFFFFF' })
  @IsHexColor()
  color: string;

  @ApiProperty({ example: 'rgba(123,123,123,0.3)' })
  @IsString() // Rgb не работает (почему-то)
  background: string;

  @ApiProperty({ example: { search: 'utm_source=share&utm_campaign=yandex' } })
  @IsObject()
  filters: object;

  @ApiProperty({ example: 1 })
  @IsNumber()
  appId: number;

  @ApiProperty({ example: ['sidebar', 'navigation'] })
  @IsOptional()
  @IsString({ each: true })
  features?: Array<string>;

  @ApiProperty({ example: ['login', 'buy'] })
  @IsOptional()
  @IsString({ each: true })
  custom_events?: Array<string>;
}

export class updateCohortBody {
  @ApiProperty({ example: 'My cohort' })
  @IsOptional()
  @IsString()
  @Length(1, 20)
  title?: string;

  @ApiProperty({ example: COHORT_COLOR.bittersweet })
  @IsOptional()
  @IsEnum(COHORT_COLOR)
  theme?: COHORT_COLOR;

  @ApiProperty({ example: '#FFFFFF' })
  @IsOptional()
  @IsHexColor()
  color?: string;

  @ApiProperty({ example: 'rgba(123,123,123,0.3)' })
  @IsOptional()
  @IsRgbColor()
  background?: string;

  @ApiProperty({ example: { search: 'utm_source=share&utm_campaign=yandex' } })
  @IsOptional()
  @IsObject()
  filters?: object;

  @ApiProperty({ example: 1 })
  @IsOptional()
  @IsNumber()
  appId?: number;

  @ApiProperty({ example: ['sidebar', 'navigation'] })
  @IsOptional()
  @IsString({ each: true })
  features?: Array<string>;

  @ApiProperty({ example: ['login', 'buy'] })
  @IsOptional()
  @IsString({ each: true })
  custom_events?: Array<string>;
}

// WIDGET
interface ICohort {
  title: string;
  color: string;
  background: string;
  filters: object;
  features: Array<string>;
  owner: number;
}

export class pushCohortsBody {
  @ApiProperty()
  @IsArray()
  cohorts: Array<ICohort>;

  @ApiProperty()
  @IsNumber()
  appId: number;
}
