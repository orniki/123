import { ApiProperty } from '@nestjs/swagger';
import { COHORT_COLOR } from '@prisma/client';

export class getCohortResponse {
  @ApiProperty({ example: 1 })
  cohort_id: number;

  @ApiProperty({ example: new Date('2023') })
  createdAt: Date;

  @ApiProperty({ example: 'Yandex' })
  title: string;

  @ApiProperty({ example: '#123456' })
  color: string;

  @ApiProperty({ example: '#123456' })
  background: string;

  @ApiProperty({ example: COHORT_COLOR.majorelle_blue })
  theme: COHORT_COLOR;

  @ApiProperty({
    example: { search: 'utm_source=yandex&utm_content=content' },
  })
  filters: object;

  @ApiProperty({ example: 1 })
  appId: number;

  @ApiProperty({ example: ['login'] })
  custom_events: Array<string>;

  @ApiProperty({ example: ['sidebar', 'navigation'] })
  features: Array<string>;

  @ApiProperty({ example: [1, 2, 3] })
  usersAllowList: Array<number>;

  @ApiProperty({ example: 1 })
  owner: number;
}
