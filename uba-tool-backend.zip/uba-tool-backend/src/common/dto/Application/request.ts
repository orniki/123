import { ApiProperty } from '@nestjs/swagger';
import {
  IsArray,
  IsDateString,
  IsNumber,
  IsNumberString,
  IsString,
} from 'class-validator';

export class getApplicationQuery {
  @ApiProperty({ example: '1' })
  @IsString()
  appId: string;

  @ApiProperty({ example: new Date('2022') })
  @IsDateString()
  from_date?: string;

  @ApiProperty({ example: new Date('2023') })
  @IsDateString()
  to_date?: string;

  @ApiProperty({ example: 'utm_source=yandex&product_id=124' })
  @IsString()
  searchString?: string;
}

export class getAppInSpaceQuery {
  @ApiProperty({ example: '1' })
  @IsString()
  space_id: string;
}

export class createApplicationBody {
  @ApiProperty({ example: 'Uba-tool' })
  @IsString()
  name: string;

  @ApiProperty({ example: 'https://uba-tool.ru' })
  @IsString()
  origin: string;

  @ApiProperty({ example: 'dev' })
  @IsString()
  version: string;

  @ApiProperty({ example: [] })
  @IsArray()
  sessions?: Array<any>;
}

interface IEventModel {
  type: string;
  custom_type?: string;
  createdAt?: Date;
  day: string;
  data: any;
  app_id: number;
  session_id: number;
}

export class postSessionChunkBody {
  @ApiProperty({ example: 1 })
  @IsNumber()
  applicationId: number;

  @ApiProperty({ example: 1 })
  @IsNumber()
  sessionId: number;

  @ApiProperty({ example: [] })
  @IsArray()
  events: Array<any>;

  @ApiProperty({ example: [] })
  @IsArray()
  Event: Array<IEventModel>;

  @ApiProperty({ example: [] })
  @IsArray()
  eventsReplay: Array<any>;
}

export class filteredSessionsQuery {
  @ApiProperty({ example: '1' })
  @IsNumberString()
  appId: string;

  @ApiProperty({ example: 'utm_source=yandex&product_id=124' })
  @IsString()
  search?: string;

  @ApiProperty({ example: new Date('2022') })
  @IsDateString()
  from_date?: string;

  @ApiProperty({ example: new Date('2023') })
  @IsDateString()
  to_date?: string;
}

export class getAppQuery {
  @ApiProperty({ example: '1' })
  @IsString()
  appName: string;

  @ApiProperty({ example: new Date('2022') })
  @IsDateString()
  from_date: Date;

  @ApiProperty({ example: new Date('2023') })
  @IsDateString()
  to_date: Date;
}
