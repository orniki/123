import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsNumber, IsString } from 'class-validator';

export class getAppResponse {
  @ApiProperty({ example: 1 })
  @IsNumber()
  id: number;

  @ApiProperty({ example: 'uba-tool' })
  @IsString()
  name: string;

  @ApiProperty({ example: 'https://uba-tool-api.ru' })
  @IsString()
  origin: string;

  @ApiProperty({ example: 'dev' })
  @IsString()
  environment: string;

  @ApiProperty({ example: ['utm_source, id'] })
  @IsArray()
  available_search: Array<string>;

  @ApiProperty({ example: 1 })
  @IsNumber()
  space_id: number;

  @ApiProperty({ example: [1, 2, 3] })
  @IsArray()
  usersAllowList: Array<number>;

  @ApiProperty({ example: 1 })
  @IsNumber()
  owner: 1;

  @ApiProperty({
    example: [
      {
        cohort_id: 1,
        title: 'Yandex',
        color: '#123456',
        background: 'rgba(255,255,255,0.5)',
        filters: {
          search: ['utm_source=yandex'],
          appId: 1,
          custom_events: ['login'],
          features: ['sidebar'],
          usersAllowList: [1, 2],
          owner: 1,
        },
      },
    ],
  })
  @IsArray()
  cohorts: Array<any>;
}

export class getAppsInSpaceResponse {
  @ApiProperty({ example: 1 })
  @IsNumber()
  id: number;

  @ApiProperty({ example: 'uba-tool' })
  @IsString()
  name: string;

  @ApiProperty({ example: 'https://uba-tool-api.ru' })
  @IsString()
  origin: string;

  @ApiProperty({ example: 'dev' })
  @IsString()
  environment: string;

  @ApiProperty({ example: ['utm_source, id'] })
  @IsArray()
  available_search: Array<string>;

  @ApiProperty({ example: 1 })
  @IsNumber()
  space_id: number;

  @ApiProperty({ example: [1, 2, 3] })
  @IsArray()
  usersAllowList: Array<string>;

  @ApiProperty({ example: 1 })
  @IsNumber()
  owner: 1;
}
