import { ApiProperty } from '@nestjs/swagger';

export class DashboardResponse {
  @ApiProperty({ example: 1 })
  dashboard_id: number;

  @ApiProperty({ example: 1 })
  applicationId: 1;

  @ApiProperty({ example: 'Dashboard title' })
  title: string;

  @ApiProperty({ example: [1, 2, 3] })
  usersAllowList: Array<number>;

  @ApiProperty({ example: 1 })
  owner: 1;
}
export class DashboardFullResponse {
  @ApiProperty({ example: 1 })
  dashboard_id: number;

  @ApiProperty({ example: 1 })
  applicationId: 1;

  @ApiProperty({ example: 'Dashboard title' })
  title: string;

  @ApiProperty({ example: [1, 2, 3] })
  usersAllowList: Array<number>;

  @ApiProperty({ example: 1 })
  owner: 1;

  @ApiProperty({
    example: [
      { w: 6, h: 1, x: 0, y: 0, i: '1' },
      { w: 6, h: 1, x: 6, y: 6, i: '2' },
    ],
  })
  positions: Array<{
    w: number;
    h: number;
    x: number;
    y: number;
    i: number;
  }>;

  @ApiProperty({
    example: [
      {
        chart_id: 1,
        dashboard_id: 1,
        pattern: 'bar',
        filters: {
          OR: [
            {
              AND: [
                {
                  utm_source: {
                    contains: 'vk',
                  },
                  utm_campaign: {
                    startsWith: 'tg',
                  },
                },
                {
                  IP: {
                    startsWith: '192',
                  },
                },
              ],
            },
          ],
        },
        data: [
          {
            name: '22-04-2023',
            click: 4000,
            mousemove: 2400,
            login: 1245,
          },
          {
            name: '23-04-2023',
            click: 3000,
            mousemove: 1398,
            login: 5666,
          },
        ],
        events: ['click', 'mousemove'],
        custom_events: ['login'],
        usersAllowList: [1, 2, 3],
        owner: 1,
        modify_history: [
          {
            user: 'test@gmail.com',
            updatedAt: new Date('2022'),
          },
        ],
        createdAt: new Date('2012'),
      },
    ],
  })
  charts: Array<any>;
}

export class EmptyDashboardResponse {
  @ApiProperty({ example: 1 })
  dashboard_id: number;

  @ApiProperty({ example: 1 })
  applicationId: 1;

  @ApiProperty({ example: 'My awesome dashboard' })
  title: string;

  @ApiProperty({ example: [] })
  usersAllowList: Array<number>;

  @ApiProperty({ example: 1 })
  owner: 1;

  @ApiProperty({
    example: [],
  })
  positions: Array<{
    w: number;
    h: number;
    x: number;
    y: number;
    i: number;
  }>;
}
