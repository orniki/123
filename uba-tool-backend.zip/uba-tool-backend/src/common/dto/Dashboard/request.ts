import { ApiProperty } from '@nestjs/swagger';
import {
  IsArray,
  IsDateString,
  IsNumber,
  IsNumberString,
  IsOptional,
  IsString,
  Length,
} from 'class-validator';

export class createDashboardBody {
  @ApiProperty({ example: 'My awesome dashboard' })
  @IsString()
  @Length(2, 30)
  title: string;

  @ApiProperty({ example: 1 })
  @IsNumber()
  applicationId: number;
}

export class getDashboardsQuery {
  @ApiProperty({ example: '1' })
  @IsNumberString()
  appId: string;
}

export class positionsBody {
  @ApiProperty({
    example: [
      { w: 6, h: 1, x: 0, y: 0, i: 1 },
      { w: 6, h: 1, x: 6, y: 6, i: 2 },
    ],
  })
  @IsArray()
  positions: Array<{
    w: number;
    h: number;
    x: number;
    y: number;
    i: number;
  }>;
}

export class patchDashboardBody {
  @ApiProperty({ example: 'Title' })
  @IsOptional()
  @IsString()
  @Length(2, 20)
  title: string;
}

export class getAllViewsQuery {
  @ApiProperty({ example: '1' })
  @IsNumberString()
  dashboardId: string;

  @ApiProperty({ example: new Date('2022-03-10').toString(), required: false })
  @IsOptional()
  @IsDateString()
  from_date?: string;

  @ApiProperty({ example: new Date('2022-03-17').toString(), required: false })
  @IsOptional()
  @IsDateString()
  to_date?: string;
}
