import { ApiProperty } from '@nestjs/swagger';
import {
  IsArray,
  IsNumber,
  IsOptional,
  IsString,
  Length,
} from 'class-validator';

export class createSpaceBody {
  @ApiProperty({ example: 'Space Title' })
  @IsString()
  @Length(2, 50)
  title: string;

  @ApiProperty({ example: 'Space Description' })
  @IsOptional()
  @IsString()
  @Length(2, 150)
  description?: string;

  @ApiProperty({ example: [1, 3, 48] })
  @IsOptional()
  @IsArray()
  usersAllowList?: Array<number>;
}

export class patchSpaceBody {
  @ApiProperty({ example: 2 })
  @IsNumber()
  space_id: number;

  @ApiProperty({ example: 'Space titiel' })
  @IsOptional()
  @IsString()
  @Length(2, 50)
  title?: string;

  @ApiProperty({ example: 'Space description' })
  @IsOptional()
  @IsString()
  @Length(2, 150)
  description?: string;
}
