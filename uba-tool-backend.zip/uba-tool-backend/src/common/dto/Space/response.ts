import { ApiProperty } from '@nestjs/swagger';

export class SpaceNotFoundResponse {
  @ApiProperty({ example: 404 })
  statusCode: number;

  @ApiProperty({ example: 'Пространство не найдено' })
  message: string;
}

export class SpaceForbiddenResponse {
  @ApiProperty({ example: 403 })
  statusCode: number;

  @ApiProperty({ example: 'У вас нет доступа к пространству' })
  message: string;
}

export class GetSpacesResponse {
  @ApiProperty({ example: 1 })
  space_id: number;

  @ApiProperty({ example: 1 })
  user_id: number;

  @ApiProperty({ example: 'Default' })
  title: string;

  @ApiProperty({ example: 'Description' })
  description?: string;

  @ApiProperty({ example: [1, 2] })
  usersAllowList: Array<number>;

  @ApiProperty({ example: 1 })
  owner: number;

  @ApiProperty({ example: 'flamekodanf@gmailcom.4cJNRy0TPJm1oLpcGlUsfj' })
  apiKey: string;

  @ApiProperty({ example: { Applications: 4 } })
  _count: {
    Applications: 4;
  };
}

export class OkGetSpaceResponse {
  @ApiProperty({ example: 1 })
  space_id: number;

  @ApiProperty({ example: 1 })
  user_id: number;

  @ApiProperty({ example: 'Default' })
  title: string;

  @ApiProperty({ example: 'Description' })
  description?: string;

  @ApiProperty({ example: [1, 2] })
  usersAllowList: Array<number>;

  @ApiProperty({ example: 1 })
  owner: number;

  @ApiProperty({ example: 'flamekodanf@gmailcom.4cJNRy0TPJm1oLpcGlUsfj' })
  apiKey: string;
}
