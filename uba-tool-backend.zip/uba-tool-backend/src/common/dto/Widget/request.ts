import { ApiProperty } from '@nestjs/swagger';
import {
  IsDateString,
  IsNumberString,
  IsOptional,
  IsString,
} from 'class-validator';

export class UtmsDto {
  @IsOptional()
  @IsString()
  utm_source?: string;

  @IsOptional()
  @IsString()
  utm_campaign?: string;

  @IsOptional()
  @IsString()
  utm_term?: string;

  @IsOptional()
  @IsString()
  utm_content?: string;

  @IsOptional()
  @IsString()
  utm_medium?: string;
}

export class getTotalClicksQuery {
  @ApiProperty({ example: '1' })
  @IsNumberString()
  appId: string;
}

export class getCohortsQuery {
  @ApiProperty({ example: '1' })
  @IsNumberString()
  appId: string;
}

export class getEventsQuery {
  @ApiProperty({ example: '1' })
  @IsNumberString()
  appId: string;

  @ApiProperty({ example: '1,2,3', required: false })
  @IsOptional()
  @IsString()
  cohorts?: string;

  @ApiProperty()
  @IsString()
  path: string;

  @ApiProperty({ example: new Date('2022') })
  @IsDateString()
  from_date: string;

  @ApiProperty({ example: new Date() })
  @IsDateString()
  to_date: string;
}
