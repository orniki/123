import { ApiProperty } from '@nestjs/swagger';
import { IsEmail, IsNumber } from 'class-validator';

export class ReqUser {
  // Используется в каждом модуле приложения
  @ApiProperty({ example: 'ubatool@gmail.com' })
  @IsEmail()
  email: string;

  @ApiProperty({ example: 1 })
  @IsNumber()
  user_id: number;
}

export class SpaceApiKey {
  // Используется в модуле виджета
  space_id: number;
  user_id: number;
  owner: number;
  title: string;
  description: string;
  usersAllowList: Array<number>;
  apiKey: string;
}
