import { ApiProperty } from '@nestjs/swagger';
import { IsEmail, IsJWT, IsString, Length } from 'class-validator';

export class verifyQuery {
  @ApiProperty({
    example:
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c',
  })
  @IsString()
  @IsJWT()
  token: string;
}

export class LoginBody {
  @ApiProperty()
  @IsEmail()
  email: string;

  @ApiProperty()
  @Length(2, 24)
  // @IsStrongPassword()
  password: string;
}

export class SignupBody {
  @ApiProperty()
  @IsEmail()
  email: string;

  @ApiProperty()
  @IsString()
  password: string;

  @ApiProperty()
  @IsString()
  @Length(2, 24)
  name: string;

  @ApiProperty()
  @IsString()
  @Length(2, 24)
  surname: string;
}
