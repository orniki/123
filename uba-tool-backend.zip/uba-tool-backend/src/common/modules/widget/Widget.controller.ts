import {
  Controller,
  Inject,
  UseGuards,
  Request,
  Post,
  Patch,
  Get,
  Body,
  Ip,
  Delete,
  Query,
  Param,
  ParseIntPipe,
} from '@nestjs/common';
import { ApiHeader, ApiOperation, ApiSecurity, ApiTags } from '@nestjs/swagger';
import { WidgetService } from './Widget.service';
import { ApiKeyAuthGuard } from '@modules/auth/api-key-auth.guard';
import {
  createApplicationBody,
  getAppQuery,
  postSessionChunkBody,
} from '@/common/dto/Application/request';
import { pushSessionBody } from '@/common/dto/Session/request';
import { createVisitorBody } from '@/common/dto/Visitor/request';
import { createCohortBody, pushCohortsBody } from '@/common/dto/Cohort/request';
import {
  getCohortsQuery,
  getEventsQuery,
  getTotalClicksQuery,
} from '@/common/dto/Widget/request';

@ApiTags('Widget')
@UseGuards(ApiKeyAuthGuard)
@ApiSecurity('Api-Key')
@Controller('widget')
@ApiHeader({
  name: 'Authorization',
  description: 'example: "Api-Key yourmail.f12hj90f1n2nf1902"',
})
export class WidgetController {
  @Inject() widgetService: WidgetService;

  @Post('app')
  @ApiOperation({ summary: 'Рекордер - создать/получить приложение' })
  async getOrCreateApp(@Body() body: createApplicationBody, @Request() req) {
    return this.widgetService.getOrCreateApp(body, req.user);
  }

  @Post('visitor')
  @ApiOperation({ summary: 'Рекордер - создать/получить посетителя' })
  async getOrCreateVisitor(@Body() body: createVisitorBody) {
    return this.widgetService.getOrCreateVisitor(body);
  }

  @Post('session')
  @ApiOperation({ summary: 'Рекордер - создать пустую сессию' })
  async createSession(@Body() body: pushSessionBody, @Ip() ip, @Request() req) {
    return this.widgetService.createSession(body, ip, req.user);
  }

  @Post('session_chunk')
  @ApiOperation({ summary: 'Рекордер - отправит чанк в сушествующую сессию' })
  async sendSessionChunk(@Body() body: postSessionChunkBody) {
    return this.widgetService.sendSessionChunk(body);
  }

  @Patch('cohorts')
  @ApiOperation({ summary: 'Рекордер - обновить данные (пресет) когорты' })
  async updateOrCreateCohorts(@Body() body: pushCohortsBody, @Request() req) {
    return this.widgetService.updateOrCreateCohorts(body, req.user);
  }

  @Get('app')
  @ApiOperation({ summary: 'Тулбар - инфа о приложении + сессии' })
  async getApplication(@Query() query: getAppQuery, @Request() req) {
    return this.widgetService.getApplication(query, req.user);
  }

  @Get('cohorts')
  @ApiOperation({ summary: 'Тулбар - получить когорты' })
  async getCohorts(@Query() query: getCohortsQuery, @Request() req) {
    return this.widgetService.getCohorts(query, req.user);
  }

  @Post('cohorts')
  @ApiOperation({ summary: 'Тулбар - получить когорты' })
  async createCohort(@Body() body: createCohortBody, @Request() req) {
    return this.widgetService.createCohort(body, req.user);
  }

  @Delete('cohort/:cohort_id')
  @ApiOperation({ summary: 'Тулбар - удалить когорту' })
  async deleteCohort(
    @Param('cohort_id', ParseIntPipe) cohort_id: number,
    @Request() req,
  ) {
    return this.widgetService.deleteCohort(cohort_id, req.user);
  }

  @Get('total_clicks')
  @ApiOperation({ summary: 'Тулбар - получить количество кликов' })
  async getClicks(@Query() query: getTotalClicksQuery, @Request() req) {
    return this.widgetService.getTotalClicks(query, req.user);
  }

  @Get('events')
  @ApiOperation({ summary: 'Тулбар - получить отфилтрованные ивенты' })
  async getEvents(@Query() query: getEventsQuery, @Request() req) {
    return this.widgetService.getEvents(query, req.user);
  }
}
