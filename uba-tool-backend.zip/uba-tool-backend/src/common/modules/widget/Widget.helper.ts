/* eslint-disable @typescript-eslint/restrict-template-expressions */
import { Injectable } from '@nestjs/common';
interface IUtmMarks {
  utm_source: string;
  utm_campaign: string;
  utm_term: string;
  utm_medium: string;
  utm_content: string;
}

@Injectable()
export class WidgetHelper {
  getUtmMarks = (search: string | undefined): IUtmMarks => {
    const searchString = search.replace('?', '');
    return searchString
      .split('&')
      .filter((v) => v.startsWith('utm'))
      .reduce<IUtmMarks | any>((acc, curr) => {
        const [key, value] = curr.split('=');
        acc[key] = value;
        return acc;
      }, {});
  };

  getCountedEvents = (arr: Array<any>) => {
    return arr.reduce<Record<string, number>>((acc, event) => {
      const eventData = event.data;
      if (acc[`${eventData.selector}`]) {
        acc[`${eventData.selector}`] = acc[`${eventData.selector}`] + 1;
      } else {
        acc[`${eventData.selector}`] = 1;
      }

      return acc;
    }, {});
  };
}
