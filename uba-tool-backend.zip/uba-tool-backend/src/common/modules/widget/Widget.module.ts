import { Module } from '@nestjs/common';
import { WidgetController } from './Widget.controller';
import { WidgetService } from './Widget.service';
import { PrismaService } from '@/common/services/prisma.service';
import { ApiKeyStrategy } from '../auth/apikey.strategy';
import { AuthHelper } from '@/shared/helpers/Auth.helper';
import { JwtService } from '@nestjs/jwt';
import { WidgetHelper } from '@modules/widget/Widget.helper';

@Module({
  controllers: [WidgetController],
  providers: [
    WidgetService,
    PrismaService,
    AuthHelper,
    JwtService,
    ApiKeyStrategy,
    WidgetHelper,
  ],
})
export class WidgetModule {}
