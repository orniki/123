/* eslint-disable @typescript-eslint/restrict-template-expressions */
import {
  createApplicationBody,
  getAppQuery,
  postSessionChunkBody,
} from '@/common/dto/Application/request';
import { SpaceApiKey } from '@/common/dto/Global.dto';
import { pushSessionBody } from '@/common/dto/Session/request';
import { createVisitorBody } from '@/common/dto/Visitor/request';
import { PrismaService } from '@/common/services/prisma.service';
import { ForbiddenException, Inject, Injectable } from '@nestjs/common';
import * as geoip from 'geoip-lite';
import { createCohortBody, pushCohortsBody } from '@/common/dto/Cohort/request';
import {
  getCohortsQuery,
  getEventsQuery,
  getTotalClicksQuery,
} from '@/common/dto/Widget/request';
import { WidgetHelper } from '@modules/widget/Widget.helper';

@Injectable()
export class WidgetService {
  @Inject() prisma: PrismaService;
  @Inject() helper: WidgetHelper;

  async getOrCreateApp(body: createApplicationBody, space: SpaceApiKey) {
    const application = await this.prisma.application.findFirst({
      where: {
        name: `${body.name}@${body.version}`,
        owner: space.user_id,
      },
    });

    if (application && application.owner === space.user_id) {
      return application;
    }

    return this.prisma.application.create({
      data: {
        name: `${body.name}@${body.version}`,
        origin: body.origin,
        owner: space.user_id,
        space_id: space.space_id,
      },
    });
  }

  async getOrCreateVisitor(body: createVisitorBody) {
    const visitor = await this.prisma.visitor.findFirst({
      where: {
        uba_id: body.uba_id,
        applicationId: body.applicationId,
      },
    });

    if (visitor) {
      return this.prisma.visitor.update({
        where: {
          applicationId_uba_id: {
            applicationId: body.applicationId,
            uba_id: body.uba_id,
          },
        },
        data: {
          last_visit: new Date(),
        },
      });
    }

    return this.prisma.visitor.create({
      data: {
        uba_id: body.uba_id,
        applicationId: body.applicationId,
        first_visit: new Date(),
        last_visit: body.last_visit || new Date(),
        total_events: body.total_events || 0,
        total_clicks: body.total_clicks || 0,
        total_sessions: body.total_sessions || 0,
      },
    });
  }

  async createSession(
    body: pushSessionBody,
    ip: string | number,
    space: SpaceApiKey,
  ) {
    const geo = geoip.lookup(ip);

    return this.prisma.session.create({
      data: {
        app: {
          connect: {
            id: body.appId,
          },
        },
        Visitor: body?.visitor_id
          ? { connect: { visitor_id: body.visitor_id } }
          : undefined,
        searchString: body.searchString,
        utm: body.utm,
        utm_campaign: body.utm_campaign,
        utm_content: body.utm_content,
        utm_source: body.utm_source,
        utm_term: body.utm_term,
        utm_medium: body.utm_medium,
        events: body.events,
        eventsReplay: body.eventsReplay,
        pageTitle: body.pageTitle,
        hrefLocation: body.hrefLocation,
        imageSource: '',
        ip_address: `${ip}`,
        device: body.device,
        platform: body.platform,
        browser: body.browser,
        recorder_version: body.recorder_version,
        country: geo?.country || 'none',
        city: geo?.city || 'none',
        agent_language: body.agent_language,
        environment: body?.environment,
        features: body?.features || [],
        owner: space.user_id,
      },
    });
  }

  async sendSessionChunk(body: postSessionChunkBody) {
    return this.prisma.application.update({
      where: {
        id: body.applicationId,
      },
      data: {
        sessions: {
          update: {
            where: {
              sessionId: body.sessionId,
            },
            data: {
              events: { push: body.events },
              Event: {
                createMany: {
                  data: body.Event,
                },
              },
              eventsReplay: { push: body.eventsReplay },
            },
          },
        },
      },
    });
  }

  async updateOrCreateCohorts(body: pushCohortsBody, space: SpaceApiKey) {
    const { cohorts, appId } = body;
    const existedCohorts = await this.prisma.cohort.findMany({
      where: {
        appId,
      },
    });

    const existedNames = existedCohorts.reduce<Array<string>>((acc, item) => {
      acc.push(item.title);
      return acc;
    }, []);

    const notCreatedCohorts = cohorts
      .filter((item) => {
        return !existedNames.includes(item.title);
      })
      .map((item) => {
        return { ...item, owner: space.owner };
      });

    return this.prisma.application.update({
      where: {
        id: appId,
      },
      data: {
        cohorts: {
          createMany: {
            data: notCreatedCohorts,
          },
        },
      },
    });
  }

  async getApplication(query: getAppQuery, space: SpaceApiKey) {
    return this.prisma.application.findFirst({
      where: {
        name: query.appName,
        space_id: space.space_id,
      },
      include: {
        cohorts: true,
        sessions: {
          where: {
            createdAt: {
              lte: new Date(query.to_date),
              gte: new Date(query.from_date),
            },
          },
        },
      },
    });
  }

  async createCohort(body: createCohortBody, space: SpaceApiKey) {
    const {
      appId,
      title,
      color,
      background,
      filters,
      features,
      custom_events,
    } = body;

    const app = await this.prisma.application.findFirst({
      where: {
        id: appId,
        space_id: space.space_id,
      },
    });

    if (!app) return new ForbiddenException();

    return this.prisma.cohort.create({
      data: {
        app: {
          connect: {
            id: appId,
          },
        },
        title,
        color,
        background,
        filters,
        features,
        custom_events,
        owner: space.owner,
      },
    });
  }

  async deleteCohort(cohort_id: number, space: SpaceApiKey) {
    const userCohort = await this.prisma.cohort.findFirst({
      where: {
        owner: space.owner,
      },
    });

    if (!userCohort) {
      return new ForbiddenException('Можно удалять только свои когорты');
    }

    return this.prisma.cohort.delete({
      where: {
        cohort_id: +cohort_id,
      },
    });
  }

  async getTotalClicks(query: getTotalClicksQuery, space: SpaceApiKey) {
    const userSpace = await this.prisma.space.findFirst({
      where: {
        apiKey: space.apiKey,
      },
    });
    if (!userSpace || space.apiKey !== userSpace.apiKey) {
      return new ForbiddenException(
        'У вас есть доступ только к своим пространствам',
      );
    }

    const clicksCount = await this.prisma.event.count({
      where: {
        app_id: +query.appId,
        type: 'click',
      },
    });

    return {
      clicks: clicksCount,
    };
  }

  async getCohorts(query: getCohortsQuery, space: SpaceApiKey) {
    const userSpace = await this.prisma.space.findFirst({
      where: {
        apiKey: space.apiKey,
      },
    });

    if (!userSpace || space.apiKey !== userSpace.apiKey) {
      return new ForbiddenException(
        'У вас есть доступ только к своим пространствам',
      );
    }

    const cohorts = await this.prisma.cohort.findMany({
      where: {
        appId: +query.appId,
      },
    });

    return cohorts;
  }

  async getEvents(query: getEventsQuery, space: SpaceApiKey) {
    const userSpace = await this.prisma.space.findFirst({
      where: {
        apiKey: space.apiKey,
      },
    });

    if (!userSpace || space.apiKey !== userSpace.apiKey) {
      return new ForbiddenException(
        'У вас есть доступ только к своим пространствам',
      );
    }

    const cohortIdFilter = query?.cohorts
      ? { cohort_id: { in: query.cohorts.split(',').map((i) => +i) } }
      : {};

    let cohorts: any = await this.prisma.cohort.findMany({
      where: {
        appId: +query.appId,
        ...cohortIdFilter,
      },
    });

    if (!query?.cohorts) {
      cohorts = [
        {
          cohort_id: 0,
          title: 'uba_without_cohort',
          color: '#EB4E27',
          background: '#EB4E27',
        },
      ];
    }

    const dataPerCohort = cohorts.map(async (cohort) => {
      const cohortFilters = cohort.filters;
      const featuresFilter = cohort?.features?.length
        ? { features: { hasEvery: cohort.features } }
        : {};
      const utmMarks = cohortFilters?.search
        ? this.helper.getUtmMarks(cohortFilters.search)
        : {};

      const sessions = await this.prisma.session.findMany({
        where: {
          appId: +query.appId,
          createdAt: {
            gte: new Date(query.from_date),
            lte: new Date(query.to_date),
          },
          ...featuresFilter,
          ...utmMarks,
        },
        select: {
          sessionId: true,
        },
      });

      let rawEvents = await this.prisma.event.findMany({
        where: {
          session_id: {
            in: sessions.map((i) => i.sessionId),
          },
          type: 'click',
        },
      });

      rawEvents = rawEvents.filter((event) => {
        return (event.data as any)?.page === query.path;
      });

      const events = this.helper.getCountedEvents(rawEvents);
      return { cohort, events };
    });

    const data: any = await Promise.all(dataPerCohort);
    return data.reduce((acc, item) => {
      // -> "html": {"cohort_title": {clicks: 25, color: "#123123"}}
      Object.entries(item.events).forEach(([selector, clicks]) => {
        if (!acc[`${selector}`]) {
          acc[`${selector}`] = {};
        }
        acc[`${selector}`][`${item?.cohort.title}`] = {
          clicks,
          color: item?.cohort.color,
        };
      });
      return acc;
    }, {});
  }
}
