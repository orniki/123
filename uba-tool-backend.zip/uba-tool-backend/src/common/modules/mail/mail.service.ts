import { MailerService } from '@nestjs-modules/mailer';
import { Inject, Injectable } from '@nestjs/common';

@Injectable()
export class MailService {
  @Inject() mailer: MailerService;
  async sendConfirmation(email: string, token: string) {
    const url = `${process.env.BASE_URL}auth/verify?token=${token}`;

    await this.mailer.sendMail({
      to: email,
      subject: 'Подтвердите учётную запись Uba-tool',
      template: './confirm_email',
      context: {
        url,
      },
    });
  }
}
