import { PrismaService } from '@/common/services/prisma.service';
import { Inject, Injectable, UnauthorizedException } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { HeaderAPIKeyStrategy } from 'passport-headerapikey';
// import { AuthService } from './Auth.service';

@Injectable()
export class ApiKeyStrategy extends PassportStrategy(
  HeaderAPIKeyStrategy,
  'api-key',
) {
  @Inject() prisma: PrismaService;
  constructor() {
    super(
      {
        header: 'Authorization',
        prefix: 'Api-Key',
      },
      true,
      async (apiKey, done) => {
        const space = await this.prisma.space.findUnique({
          where: {
            apiKey: apiKey.trim(),
          },
        });

        if (!space) {
          return done(new UnauthorizedException());
        }
        return done(null, space);
      },
    );
  }
}
