import { LocalStrategy } from './local.strategy';
import { JwtModule, JwtService } from '@nestjs/jwt';
import { AuthHelper } from '@/shared/helpers/Auth.helper';
import { MailService } from '@common/modules/mail/mail.service';
import { PrismaService } from '@common/services/prisma.service';
import { AuthService } from './Auth.service';
import { AuthController } from './Auth.controller';
import { Module } from '@nestjs/common';
import { PassportModule } from '@nestjs/passport';
import { UserModule } from '../user/User.module';
import { ApiKeyStrategy } from './apikey.strategy';

@Module({
  controllers: [AuthController],
  imports: [
    PassportModule.register({ defaultStrategy: 'local' }),
    UserModule,
    JwtModule.register({
      secret: process.env.JWT_SECRET || 'secret',
      signOptions: { expiresIn: '60s' },
    }),
  ],
  exports: [AuthService],
  providers: [
    AuthService,
    PrismaService,
    MailService,
    AuthHelper,
    JwtService,
    LocalStrategy,
    PassportModule,
    ApiKeyStrategy,
  ],
})
export class AuthModule {}
