import { User } from '@prisma/client';
import { JwtService } from '@nestjs/jwt';
import { AuthHelper } from '@/shared/helpers/Auth.helper';
import { PrismaService } from '@common/services/prisma.service';
import {
  BadRequestException,
  ConflictException,
  Inject,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import { MailService } from '../mail/mail.service';
import { generateApiKey } from 'generate-api-key';
import { SignupBody, verifyQuery } from '@/common/dto/Auth/request';

@Injectable()
export class AuthService {
  @Inject() prisma: PrismaService;
  @Inject() authHelper: AuthHelper;
  @Inject() jwtService: JwtService;
  @Inject() mailService: MailService;

  async login(user: User) {
    const payload = { email: user.email, sub: user.user_id };
    const currUser = await this.prisma.user.findUnique({
      where: { email: user.email },
    });
    if (!currUser?.activated) return new UnauthorizedException();
    return {
      access_token: this.jwtService.sign(payload, {
        secret: process.env.JWT_SECRET,
      }),
    };
  }

  async verifyUser(query: verifyQuery) {
    if (!query.token) return new UnauthorizedException();
    const verifiedUser = this.jwtService.verify(query.token, {
      secret: process.env.JWT_SECRET,
    });
    if (!verifiedUser) return new UnauthorizedException();
    await this.prisma.user.update({
      where: {
        email: verifiedUser.email,
      },
      data: {
        activated: true,
      },
    });
    return {
      access_token: query.token,
    };
  }

  async signup(body: SignupBody) {
    const { email, password, name, surname } = body;

    const existedUser = await this.prisma.user.findFirst({
      where: {
        email,
      },
    });

    if (existedUser) {
      return new ConflictException(
        `Пользователь с почтой ${email} уже создан.`,
      );
    }

    const user = await this.prisma.user.create({
      data: {
        email,
        password: bcrypt.hashSync(password, 10),
        name,
        surname,
      },
    });

    if (!user) return new BadRequestException();

    await this.prisma.user.update({
      where: {
        user_id: user.user_id,
      },
      data: {
        spaces: {
          create: {
            title: `${email} Space`,
            usersAllowList: [user.user_id],
            owner: user.user_id,
            apiKey: generateApiKey({
              method: 'base62',
              prefix: email,
            }) as string,
          },
        },
      },
    });

    const payload = { email: user.email, sub: user.user_id };
    const jwtToken = this.jwtService.sign(payload, {
      secret: process.env.JWT_SECRET,
    });

    // send email
    await this.mailService.sendConfirmation(user.email, jwtToken);
    return {
      message: 'email sended',
    };
  }

  async validateUser(email: string, password: string) {
    const user = await this.prisma.user.findUnique({
      where: {
        email,
      },
    });
    if (!user) return null;
    const isPasswordsEqual = await this.authHelper.isPasswordValid(
      password,
      user.password,
    );
    if (isPasswordsEqual) {
      const { password, ...result } = user;
      return result;
    }
    return null;
  }

  async validateApiKey(apiKey: string) {
    return this.prisma.space.findUnique({
      where: {
        apiKey,
      },
    });
  }
}
