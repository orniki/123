import { LocalAuthGuard } from './local-auth.guard';
import { MailService } from './../mail/mail.service';
import { AuthService } from './Auth.service';
import {
  Body,
  Controller,
  Get,
  Inject,
  Post,
  Query,
  Request,
  UseGuards,
  Version,
} from '@nestjs/common';
import { ApiOkResponse, ApiOperation, ApiTags } from '@nestjs/swagger';
import { LoginBody, SignupBody, verifyQuery } from '@/common/dto/Auth/request';
import {
  LoginOkResponse,
  SignupOkResponse,
  VerifyUserOkResponse,
} from '@/common/dto/Auth/response';

@ApiTags('Auth')
@Controller({ path: 'auth', version: ['1', '2'] })
export class AuthController {
  @Inject() mailService: MailService;
  @Inject() authService: AuthService;

  @Post('sign_in')
  @Version('1')
  @UseGuards(LocalAuthGuard)
  @ApiOperation({ summary: 'Логин' })
  @ApiOkResponse({ type: LoginOkResponse })
  async signin(@Request() req, @Body() body: LoginBody) {
    return this.authService.login(req.user);
  }

  @Post('sign_up')
  @Version('1')
  @ApiOperation({ summary: 'Регистрация' })
  @ApiOkResponse({ type: SignupOkResponse })
  async signup(@Body() body: SignupBody) {
    return this.authService.signup(body);
  }

  @Get('verify')
  @Version('1')
  @ApiOperation({ summary: 'Подтверждение почты' })
  @ApiOkResponse({ type: VerifyUserOkResponse })
  async verifyEmail(@Query() query: verifyQuery) {
    return this.authService.verifyUser(query);
  }

  @Post('reset_password')
  @Version('2')
  @ApiOperation({ summary: 'WIP: Восстановление пароля' })
  async resetPassword() {
    return 'reset';
  }

  @Get('get_otp')
  @Version('2')
  @ApiOperation({ summary: 'WIP: Сгенерить otp' })
  async getOtp() {
    return 'otp';
  }
}
