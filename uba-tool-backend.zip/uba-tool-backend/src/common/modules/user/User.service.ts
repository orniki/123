import { ReqUser } from '@/common/dto/Global.dto';
import { changePasswordBody } from '@/common/dto/User/request';
import { AuthHelper } from '@/shared/helpers/Auth.helper';
import { PrismaService } from '@common/services/prisma.service';
import { ForbiddenException, Inject, Injectable } from '@nestjs/common';
import * as bcrypt from 'bcrypt';

@Injectable()
export class UserService {
  @Inject() prisma: PrismaService;
  @Inject() authHelper: AuthHelper;
  async updateUser() {
    return 'updated user';
  }

  async findOne(email) {
    return this.prisma.user.findUnique({
      where: {
        email,
      },
    });
  }

  async getMe(req: ReqUser) {
    const user = await this.prisma.user.findUnique({
      where: {
        user_id: req.user_id,
      },
    });
    const { password, ...userWithoutPassword } = user;
    return userWithoutPassword;
  }

  async changePassword(body: changePasswordBody, req: ReqUser) {
    const user = await this.prisma.user.findUnique({
      where: {
        user_id: req.user_id,
      },
    });
    const isSamePassword = bcrypt.compareSync(body.old_password, user.password);
    if (!isSamePassword) {
      return new ForbiddenException();
    }
    const updatedUser = await this.prisma.user.update({
      where: {
        user_id: req.user_id,
      },
      data: {
        password: bcrypt.hashSync(body.new_password, 10),
      },
    });

    const { password, ...userWithoutPass } = updatedUser;
    return userWithoutPass;
  }
}
