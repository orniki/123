import { JwtAuthGuard } from '@modules/auth/jwt-auth.guard';
import { UserService } from './User.service';
import {
  Controller,
  Get,
  UseGuards,
  Request,
  Inject,
  Put,
  Body,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiHeader,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
} from '@nestjs/swagger';
import { UserOkResponse } from '@/common/dto/User/response';
import { changePasswordBody } from '@/common/dto/User/request';

@ApiTags('Users')
@UseGuards(JwtAuthGuard)
@ApiHeader({ name: 'Authorization' })
@Controller('users')
@ApiBearerAuth()
export class UserController {
  @Inject() userService: UserService;

  @Get('me')
  @ApiOperation({ summary: 'Получить данные о профиле пользователя' })
  @ApiOkResponse({ type: UserOkResponse })
  async getMe(@Request() req) {
    return this.userService.getMe(req.user);
  }

  @Put('change_password')
  @ApiOperation({
    summary: "Change user's password",
  })
  @ApiOkResponse({ type: UserOkResponse })
  async changePassword(@Body() body: changePasswordBody, @Request() req) {
    return this.userService.changePassword(body, req.user);
  }
}
