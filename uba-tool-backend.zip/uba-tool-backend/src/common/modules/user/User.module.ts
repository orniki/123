import { JwtService } from '@nestjs/jwt';
import { AuthHelper } from '@/shared/helpers/Auth.helper';
import { PrismaService } from '@common/services/prisma.service';
import { UserService } from './User.service';
import { UserController } from './User.controller';
import { Module } from '@nestjs/common';
import { JwtStrategy } from '../auth/jwt.strategy';

@Module({
  controllers: [UserController],
  providers: [UserService, PrismaService, AuthHelper, JwtService, JwtStrategy],
})
export class UserModule {}
