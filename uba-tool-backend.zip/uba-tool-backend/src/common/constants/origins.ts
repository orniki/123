export const origins: Array<string> = [
  'https://frontend-decide.vercel.app',
  'https://decide-career.com',
  'http://localhost:5173',
  'https://uba-tool-dashboard-git-dev-orniki.vercel.app',
  'https://uba-tool-dashboard.vercel.app',
];
