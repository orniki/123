import { canvasEventWithTime } from '@rrweb/types';

export interface IEvents {
  type: string;
  data: object;
}

export interface SessionPost {
  utm: object;
  events: Array<IEvents>;
  pageTitle: string;
  imageSource: string;
  eventsReplay: Array<canvasEventWithTime>;
  hrefLocation: string;
  appId: string;
}
