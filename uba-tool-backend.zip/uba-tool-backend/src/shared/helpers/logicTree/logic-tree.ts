/* eslint-disable array-callback-return */
/* eslint-disable @typescript-eslint/restrict-template-expressions */
import { BracketNode } from './node';
import { IAndParam, IBracketNode, IRelText } from './types';

const OPERATOR_OR = ' || ';
const OPERATOR_AND = ' && ';

const buildAndParam = (
  bracketNodes: Array<IBracketNode>,
  paramText: Partial<IRelText>,
  filters: any,
): Partial<IAndParam> => {
  const andParam = BracketNode.paramFromRelText(
    paramText,
  ) as Partial<IAndParam>;
  const bracketNode = bracketNodes[BracketNode.decodeNodeID(andParam.name)];

  if (!bracketNode) {
    return andParam;
  }

  andParam.OR = bracketNode.relText
    .split(OPERATOR_OR)
    .map((orPartName) => buildOrParam(bracketNode.nodes, orPartName, filters));

  const { name, ...rAndParam } = andParam;
  return rAndParam;
};

const buildOrParam = (
  bracketNodes: Array<IBracketNode>,
  orPartText: string,
  filters: any,
): any => {
  const andParams = orPartText
    .split(OPERATOR_AND)
    .map((andParamName) => buildAndParam(bracketNodes, andParamName, filters));
  const resultedParams = [];
  for (let param of andParams) {
    param = { ...filters[`${param.name}`] };
    if (Object.values(param).length) {
      for (const val of Object.entries(param)) {
        const [key, value] = val as any;
        param[`${key}`] = {};
        param[`${key}`][`${value.filter}`] = value.value;
        console.log('param: ', JSON.stringify(param));
      }
      resultedParams.push(param);
    }
  }
  if (resultedParams.length) {
    console.log('resultedAnd: ', resultedParams);
  }
  return {
    // AND: andParams,
    AND: resultedParams?.length ? resultedParams : andParams,
  };
};

class LogicTree {
  root: any;
  filters: any;

  constructor(bracketTreeRoot: IBracketNode, filters: any) {
    this.root = buildAndParam(
      bracketTreeRoot.nodes,
      bracketTreeRoot.relText,
      filters,
    );
  }
}

export default LogicTree;
