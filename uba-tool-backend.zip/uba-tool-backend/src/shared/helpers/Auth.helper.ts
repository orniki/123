import { PrismaService } from '@common/services/prisma.service';
import {
  HttpException,
  HttpStatus,
  Inject,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { User } from '@prisma/client';
import * as bcrypt from 'bcrypt';

@Injectable()
export class AuthHelper {
  @Inject() prisma: PrismaService;
  @Inject() jwt: JwtService;

  constructor(jwt: JwtService) {
    this.jwt = jwt;
  }

  public async decode(token: string): Promise<any> {
    return this.jwt.decode(token, null);
  }

  public async validateUser(decoded: any) {
    return this.prisma.user.findUnique({ where: { user_id: decoded.id } });
  }

  public generateToken(user: any) {
    return this.jwt.sign({
      user_id: user.user_id,
      email: user.email,
      name: user.name,
      surname: user.surname,
    });
  }

  public isPasswordValid(password: string, userPassword: string): boolean {
    return bcrypt.compareSync(password, userPassword);
  }

  public async validate(token: string): Promise<boolean | never> {
    try {
      const decoded: any = this.jwt.verify(token);

      if (!decoded) {
        throw new HttpException('Forbidden', HttpStatus.FORBIDDEN);
      }
      const user: User = await this.validateUser(decoded);
      if (!user) {
        throw new UnauthorizedException();
      }
      return true;
    } catch (err) {
      throw new HttpException(err.message.toUpperCase(), HttpStatus.FORBIDDEN);
    }
  }
}
