export const getUrl = (str: string): string => {
  if (typeof str !== 'string') return '';
  const siteWithoutQuery = str.split('?')[0];
  const pathArray = siteWithoutQuery.split('/');
  const protocol = pathArray[0];
  const host = pathArray[2];
  const url = `${protocol}//${host}`;
  return url;
};
