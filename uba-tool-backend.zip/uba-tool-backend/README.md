NestJS - new api for uba_tool
